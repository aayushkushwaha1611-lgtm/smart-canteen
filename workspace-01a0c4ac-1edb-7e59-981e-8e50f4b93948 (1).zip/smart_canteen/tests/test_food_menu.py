"""Tests: food management, categories and menu browsing."""
from app import db
from app.models import Category, FoodItem


def test_menu_lists_food(client, foods):
    resp = client.get("/menu")
    assert resp.status_code == 200
    assert b"Masala Dosa" in resp.data


def test_menu_search(client):
    resp = client.get("/menu?q=poha")
    assert b"Poha" in resp.data
    assert b"Masala Dosa" not in resp.data


def test_menu_filter_price(client):
    resp = client.get("/menu?min_price=50&max_price=100")
    assert b"Masala Dosa" in resp.data  # ₹70
    assert b"Poha" not in resp.data  # ₹35


def test_menu_filter_category(client):
    resp = client.get("/menu/category/breakfast")
    assert b"Masala Dosa" in resp.data


def test_menu_sort_price_asc(client):
    resp = client.get("/menu?sort=price_asc")
    assert resp.data.find(b"Idli") < resp.data.find(b"Masala Dosa")


def test_food_detail(client, foods):
    resp = client.get(f"/food/{foods['masala-dosa'].id}")
    assert resp.status_code == 200
    assert b"Masala Dosa" in resp.data
    assert b"70" in resp.data


def test_food_detail_404(client):
    resp = client.get("/food/9999")
    assert resp.status_code == 404


def test_admin_add_food(admin):
    resp = admin.post(
        "/admin/food/add",
        data={
            "name": "Paneer Roll",
            "category_id": 1,
            "price": "90.50",
            "description": "Tasty roll",
            "prep_time_minutes": 12,
            "stock_quantity": 20,
            "low_stock_threshold": 4,
            "is_available": "y",
            "is_active": "y",
        },
        follow_redirects=True,
    )
    assert resp.status_code == 200
    food = FoodItem.query.filter_by(name="Paneer Roll").first()
    assert food is not None
    assert abs(float(food.price) - 90.5) < 0.001
    assert food.stock_quantity == 20


def test_admin_edit_food(admin, foods):
    food = foods["poha"]
    resp = admin.post(
        f"/admin/food/{food.id}/edit",
        data={
            "name": "Poha Special",
            "category_id": food.category_id,
            "price": "40",
            "description": "Updated",
            "prep_time_minutes": 8,
            "stock_quantity": 12,
            "low_stock_threshold": 3,
            "is_available": "y",
            "is_active": "y",
        },
        follow_redirects=True,
    )
    assert resp.status_code == 200
    db.session.refresh(food)
    assert food.name == "Poha Special"
    assert food.stock_quantity == 12


def test_admin_delete_food_deactivates(admin, foods):
    food = foods["idli"]
    admin.post(f"/admin/food/{food.id}/delete", follow_redirects=True)
    db.session.refresh(food)
    assert food.is_active is False
    # no longer on the menu page
    resp = admin.get("/menu")
    assert b"Idli" not in resp.data


def test_admin_toggle_availability(admin, foods):
    food = foods["masala-dosa"]
    admin.post(
        f"/admin/food/{food.id}/availability",
        data={"available": "0"},
        follow_redirects=True,
    )
    db.session.refresh(food)
    assert food.is_available is False


def test_cannot_enable_availability_with_zero_stock(admin, foods):
    food = foods["idli"]
    food.stock_quantity = 0
    food.is_available = False
    db.session.commit()
    admin.post(
        f"/admin/food/{food.id}/availability",
        data={"available": "1"},
        follow_redirects=True,
    )
    db.session.refresh(food)
    assert food.is_available is False


def test_category_create(admin):
    resp = admin.post(
        "/admin/categories",
        data={"name": "Desserts", "description": "Sweet stuff", "sort_order": 9, "is_active": "y"},
        follow_redirects=True,
    )
    assert resp.status_code == 200
    cat = Category.query.filter_by(slug="desserts").first()
    assert cat is not None


def test_category_duplicate_name(admin):
    admin.post(
        "/admin/categories",
        data={"name": "Beverages", "sort_order": 1, "is_active": "y"},
        follow_redirects=True,
    )
    resp = admin.post(
        "/admin/categories",
        data={"name": "Beverages", "sort_order": 2, "is_active": "y"},
        follow_redirects=True,
    )
    assert Category.query.filter_by(name="Beverages").count() == 1


def test_category_edit_and_toggle(admin):
    cat = Category.query.filter_by(slug="breakfast").first()
    admin.post(
        f"/admin/categories/{cat.id}/edit",
        data={"name": "Morning", "sort_order": 5, "is_active": "y"},
        follow_redirects=True,
    )
    db.session.refresh(cat)
    assert cat.name == "Morning"
    admin.post(f"/admin/categories/{cat.id}/toggle", follow_redirects=True)
    db.session.refresh(cat)
    assert cat.is_active is False
