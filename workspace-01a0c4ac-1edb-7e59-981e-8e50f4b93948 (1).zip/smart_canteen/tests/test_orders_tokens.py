"""Tests: token uniqueness, order tracking, status workflow and cancellation."""
from datetime import datetime, timedelta

import pytest

from app import db
from app.models import Order, OrderStatus, OrderStatusHistory, Token, User
from app.services.order_service import OrderError, OrderService


def place(student, foods, slug="poha", qty=1):
    student.post("/cart/add", data={"food_id": foods[slug].id, "quantity": qty})
    student.post("/checkout", data={"confirm": "y"}, follow_redirects=False)
    return Order.query.order_by(Order.id.desc()).first()


def test_order_history_and_detail(student, foods):
    order = place(student, foods)
    resp = student.get("/orders")
    assert resp.status_code == 200
    assert order.order_number.encode() in resp.data
    resp = student.get(f"/orders/{order.id}")
    assert resp.status_code == 200
    assert b"Live tracking" in resp.data


def test_confirmation_page_shows_token(student, foods):
    order = place(student, foods)
    resp = student.get(f"/orders/{order.id}/confirmation")
    assert order.token.token_number.encode() in resp.data


def test_cannot_view_other_students_order(student, foods, app):
    order = place(student, foods)
    other = app.test_client()
    other.post(
        "/register",
        data={
            "full_name": "Other Student",
            "email": "other@test.edu",
            "roll_number": "TYCS-888",
            "password": "Password123",
            "confirm_password": "Password123",
            "accept_terms": "y",
        },
    )
    resp = other.get(f"/orders/{order.id}")
    assert resp.status_code == 403


def test_daily_tokens_are_unique_and_sequential(app, student, foods):
    o1 = place(student, foods, "poha")
    o2 = place(student, foods, "masala-dosa")
    o3 = place(student, foods, "idli")
    t1, t2, t3 = o1.token, o2.token, o3.token
    assert len({t1.token_number, t2.token_number, t3.token_number}) == 3
    assert t1.daily_serial < t2.daily_serial < t3.daily_serial
    assert t2.daily_serial == t1.daily_serial + 1


def test_token_linked_one_to_one(student, foods):
    order = place(student, foods)
    assert Token.query.filter_by(order_id=order.id).count() == 1
    assert order.token.order_id == order.id


def test_status_history_recorded(student, foods):
    order = place(student, foods)
    history = OrderStatusHistory.query.filter_by(order_id=order.id).all()
    assert len(history) == 1
    assert history[0].status == OrderStatus.ORDER_PLACED


def test_admin_status_workflow(admin, student, foods):
    order = place(student, foods)
    for action, expected in [
        ("confirm", OrderStatus.CONFIRMED),
        ("prepare", OrderStatus.PREPARING),
        ("ready", OrderStatus.READY_FOR_PICKUP),
        ("complete", OrderStatus.COMPLETED),
    ]:
        resp = admin.post(
            f"/admin/orders/{order.id}/status",
            data={"action": action},
            follow_redirects=True,
        )
        assert resp.status_code == 200
        db.session.refresh(order)
        assert order.status == expected

    # full history of 5 entries
    assert OrderStatusHistory.query.filter_by(order_id=order.id).count() == 5


def test_invalid_status_transition_rejected(admin, student, foods):
    order = place(student, foods)
    # order_placed cannot jump straight to completed
    resp = admin.post(
        f"/admin/orders/{order.id}/status",
        data={"action": "complete"},
        follow_redirects=True,
    )
    db.session.refresh(order)
    assert order.status == OrderStatus.ORDER_PLACED
    assert b"Cannot change" in resp.data

    # unknown actions are rejected too
    resp = admin.post(
        f"/admin/orders/{order.id}/status",
        data={"action": "hack"},
        follow_redirects=True,
    )
    db.session.refresh(order)
    assert order.status == OrderStatus.ORDER_PLACED


def test_student_cancel_restores_stock(student, foods):
    food = foods["poha"]
    start_stock = food.stock_quantity
    order = place(student, foods, "poha", qty=2)
    assert food.stock_quantity == start_stock - 2
    resp = student.post(f"/orders/{order.id}/cancel", follow_redirects=True)
    assert resp.status_code == 200
    db.session.refresh(order)
    db.session.refresh(food)
    assert order.status == OrderStatus.CANCELLED
    assert food.stock_quantity == start_stock
    assert order.cancelled_at is not None


def test_cancel_not_allowed_after_preparing(student, foods):
    order = place(student, foods)
    order.status = OrderStatus.PREPARING
    db.session.commit()
    student.post(f"/orders/{order.id}/cancel", follow_redirects=True)
    db.session.refresh(order)
    assert order.status == OrderStatus.PREPARING


def test_cancel_window_enforced(student, foods):
    order = place(student, foods)
    order.created_at = datetime.utcnow() - timedelta(hours=3)
    db.session.commit()
    ok, reason = OrderService.can_student_cancel(order)
    assert ok is False
    assert "window" in reason.lower()


def test_completed_order_is_terminal(student, foods):
    order = place(student, foods)
    order.status = OrderStatus.COMPLETED
    db.session.commit()
    user = User.query.filter_by(email="student@test.edu").first()
    with pytest.raises(OrderError):
        OrderService.cancel_order(order, user)
    with pytest.raises(OrderError):
        OrderService.change_status(order, "confirm", user)


def test_order_includes_status_and_time_in_views(student, foods):
    order = place(student, foods)
    resp = student.get(f"/orders/{order.id}")
    assert order.order_number.encode() in resp.data
    assert order.token.token_number.encode() in resp.data


def test_student_dashboard_shows_current_order(student, foods):
    order = place(student, foods)
    resp = student.get("/dashboard")
    assert resp.status_code == 200
    assert order.token.token_number.encode() in resp.data
