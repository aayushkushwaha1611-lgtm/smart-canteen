"""Tests: cart operations, checkout, stock validation and token generation."""
from app import db
from app.models import FoodItem, Order, OrderItem, Token, Notification, CartItem

FETCH = {"X-Requested-With": "fetch"}


def add_to_cart(client, food_id, qty=1):
    return client.post(
        "/cart/add", data={"food_id": food_id, "quantity": qty}, headers=FETCH
    )


def test_add_to_cart(student, foods):
    resp = add_to_cart(student, foods["masala-dosa"].id, 2)
    assert resp.status_code == 200
    assert resp.is_json and resp.get_json()["ok"] is True
    assert resp.get_json()["cart_count"] == 2


def test_add_merges_quantities(student, foods):
    add_to_cart(student, foods["poha"].id, 1)
    add_to_cart(student, foods["poha"].id, 2)
    line = CartItem.query.first()
    assert line.quantity == 3


def test_add_rejects_unknown_food(student):
    resp = add_to_cart(student, 9999)
    assert resp.get_json()["ok"] is False


def test_add_rejects_out_of_stock(student, foods):
    food = foods["idli"]
    food.stock_quantity = 0
    food.is_available = False
    db.session.commit()
    resp = add_to_cart(student, food.id)
    assert resp.get_json()["ok"] is False


def test_add_rejects_over_stock(student, foods):
    food = foods["idli"]  # stock 3
    resp = add_to_cart(student, food.id, 5)
    assert resp.get_json()["ok"] is False
    assert "stock" in resp.get_json()["message"].lower()


def test_update_cart_quantity(student, foods):
    add_to_cart(student, foods["poha"].id, 1)
    line = CartItem.query.first()
    resp = student.post(
        f"/cart/item/{line.id}/update", data={"quantity": 4}, headers=FETCH
    )
    assert resp.get_json()["ok"] is True
    db.session.refresh(line)
    assert line.quantity == 4


def test_update_quantity_capped_by_stock(student, foods):
    add_to_cart(student, foods["idli"].id, 2)  # stock 3
    line = CartItem.query.first()
    resp = student.post(
        f"/cart/item/{line.id}/update", data={"quantity": 9}, headers=FETCH
    )
    assert resp.get_json()["ok"] is False


def test_increment_decrement(student, foods):
    add_to_cart(student, foods["poha"].id, 2)
    line = CartItem.query.first()
    student.post(
        f"/cart/item/{line.id}/update", data={"action": "inc"}, headers=FETCH
    )
    assert CartItem.query.first().quantity == 3
    student.post(
        f"/cart/item/{line.id}/update", data={"action": "dec"}, headers=FETCH
    )
    assert CartItem.query.first().quantity == 2


def test_remove_from_cart(student, foods):
    add_to_cart(student, foods["poha"].id, 1)
    line = CartItem.query.first()
    student.post(f"/cart/item/{line.id}/remove", headers=FETCH)
    assert CartItem.query.count() == 0


def test_clear_cart(student, foods):
    add_to_cart(student, foods["poha"].id, 1)
    add_to_cart(student, foods["masala-dosa"].id, 1)
    student.post("/cart/clear", headers=FETCH)
    assert CartItem.query.count() == 0


def test_cart_page_renders(student, foods):
    add_to_cart(student, foods["poha"].id, 1)
    resp = student.get("/cart")
    assert resp.status_code == 200
    assert b"Poha" in resp.data


def test_form_post_redirects_without_ajax(student, foods):
    """Classic form posts must work too (progressive enhancement)."""
    resp = student.post(
        "/cart/add", data={"food_id": foods["poha"].id, "quantity": 1}
    )
    assert resp.status_code == 302


def test_checkout_page_blocks_empty_cart(student):
    resp = student.get("/checkout", follow_redirects=True)
    assert b"empty" in resp.data.lower()


def test_checkout_creates_order_with_token(student, foods, app):
    add_to_cart(student, foods["masala-dosa"].id, 1)
    add_to_cart(student, foods["poha"].id, 2)
    resp = student.post(
        "/checkout",
        data={"notes": "Less spicy", "confirm": "y"},
        follow_redirects=False,
    )
    assert resp.status_code == 302
    assert "/confirmation" in resp.headers["Location"]

    order = Order.query.first()
    assert order is not None
    assert order.status == "order_placed"
    # server-side total: 70 + 2*35 = 140
    assert abs(order.total_float - 140.0) < 0.001
    assert order.notes == "Less spicy"
    assert len(order.items) == 2

    # token generated, unique per order
    token = Token.query.filter_by(order_id=order.id).first()
    assert token is not None
    assert token.token_number.startswith("A")

    # stock reduced, cart cleared
    assert foods["masala-dosa"].stock_quantity == 9
    assert foods["poha"].stock_quantity == 3
    assert CartItem.query.count() == 0

    # notifications created for the student
    notifs = Notification.query.all()
    assert any(
        "placed" in n.message.lower() or "token" in n.message.lower() for n in notifs
    )


def test_checkout_auto_disables_at_zero_stock(student, foods):
    food = foods["idli"]  # stock 3
    add_to_cart(student, food.id, 3)
    student.post("/checkout", data={"confirm": "y"}, follow_redirects=True)
    db.session.refresh(food)
    assert food.stock_quantity == 0
    assert food.is_available is False


def test_checkout_requires_confirmation(student, foods):
    add_to_cart(student, foods["poha"].id, 1)
    student.post("/checkout", data={"confirm": ""}, follow_redirects=True)
    assert Order.query.count() == 0  # nothing was placed


def test_checkout_validates_stock_again(student, foods):
    """Stock shrinks after items are carted → checkout must fail safely."""
    food = foods["masala-dosa"]
    add_to_cart(student, food.id, 5)
    food.stock_quantity = 2  # kitchen sold some at the counter
    db.session.commit()
    student.post("/checkout", data={"confirm": "y"}, follow_redirects=True)
    assert Order.query.count() == 0


def test_checkout_never_negative_stock(student, foods):
    food = foods["poha"]  # stock 5
    add_to_cart(student, food.id, 5)
    student.post("/checkout", data={"confirm": "y"}, follow_redirects=True)
    db.session.refresh(food)
    assert food.stock_quantity == 0
    assert food.stock_quantity >= 0


def test_server_side_price_ignores_client(student, foods, app):
    """Total is always computed from DB prices, never from client input."""
    add_to_cart(student, foods["masala-dosa"].id, 1)
    student.post(
        "/checkout",
        data={"confirm": "y", "total_amount": "1", "price": "0.01"},
        follow_redirects=True,
    )
    order = Order.query.first()
    assert abs(order.total_float - 70.0) < 0.001
    line = OrderItem.query.first()
    assert abs(float(line.price) - 70.0) < 0.001
