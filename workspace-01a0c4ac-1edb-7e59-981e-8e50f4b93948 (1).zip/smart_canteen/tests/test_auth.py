"""Tests: registration, login, logout, profile and authorization."""
from app.models import User


def test_register_success(client, app):
    resp = client.post(
        "/register",
        data={
            "full_name": "Aarav Sharma",
            "email": "aarav@test.edu",
            "roll_number": "TYCS-001",
            "password": "Password123",
            "confirm_password": "Password123",
            "accept_terms": "y",
        },
        follow_redirects=False,
    )
    assert resp.status_code == 302
    user = User.query.filter_by(email="aarav@test.edu").first()
    assert user is not None
    assert user.role == "student"
    assert user.password_hash != "Password123"  # never stored in plain text


def test_register_duplicate_email(client, student):
    resp = client.post(
        "/register",
        data={
            "full_name": "Copy Cat",
            "email": "student@test.edu",
            "roll_number": "TYCS-111",
            "password": "Password123",
            "confirm_password": "Password123",
            "accept_terms": "y",
        },
        follow_redirects=True,
    )
    assert User.query.filter_by(email="student@test.edu").count() == 1
    assert b"already exists" in resp.data or b"already" in resp.data


def test_register_duplicate_roll(client, student, app):
    resp = client.post(
        "/register",
        data={
            "full_name": "Copy Cat",
            "email": "copy@test.edu",
            "roll_number": "TYCS-999",
            "password": "Password123",
            "confirm_password": "Password123",
            "accept_terms": "y",
        },
        follow_redirects=True,
    )
    assert b"already registered" in resp.data or b"already" in resp.data


def test_register_password_mismatch(client, app):
    resp = client.post(
        "/register",
        data={
            "full_name": "Mismatch",
            "email": "mm@test.edu",
            "roll_number": "TYCS-333",
            "password": "Password123",
            "confirm_password": "Different456",
            "accept_terms": "y",
        },
        follow_redirects=True,
    )
    assert b"match" in resp.data
    assert User.query.filter_by(email="mm@test.edu").first() is None


def test_login_success(client, student, app):
    client.post("/logout")
    resp = client.post(
        "/login",
        data={"email": "student@test.edu", "password": "Password123"},
        follow_redirects=False,
    )
    assert resp.status_code == 302
    assert resp.headers["Location"].endswith("/dashboard")


def test_login_wrong_password(client, student, app):
    client.post("/logout")
    resp = client.post(
        "/login",
        data={"email": "student@test.edu", "password": "wrongpass"},
        follow_redirects=True,
    )
    assert b"Invalid email or password" in resp.data


def test_login_unknown_email(client, app):
    resp = client.post(
        "/login",
        data={"email": "ghost@test.edu", "password": "whatever"},
        follow_redirects=True,
    )
    assert b"Invalid email or password" in resp.data


def test_login_deactivated_account(client, app):
    user = User.query.filter_by(email="student@test.edu").first() if User.query.filter_by(
        email="student@test.edu"
    ).first() else None
    client.post(
        "/register",
        data={
            "full_name": "Deactivated User",
            "email": "deact@test.edu",
            "roll_number": "TYCS-222",
            "password": "Password123",
            "confirm_password": "Password123",
            "accept_terms": "y",
        },
    )
    client.post("/logout")
    user = User.query.filter_by(email="deact@test.edu").first()
    user.is_active = False
    from app import db

    db.session.commit()
    resp = client.post(
        "/login",
        data={"email": "deact@test.edu", "password": "Password123"},
        follow_redirects=True,
    )
    assert b"deactivated" in resp.data


def test_logout(client, student):
    resp = client.post("/logout", follow_redirects=False)
    assert resp.status_code == 302
    # protected page should redirect to login after logout
    resp = client.get("/cart")
    assert resp.status_code == 302
    assert "/login" in resp.headers["Location"]


def test_protected_route_requires_login(client):
    for path in ["/dashboard", "/cart", "/checkout", "/orders", "/notifications", "/profile"]:
        resp = client.get(path)
        assert resp.status_code == 302
        assert "/login" in resp.headers["Location"]


def test_admin_routes_forbidden_for_students(student):
    for path in [
        "/admin/",
        "/admin/orders",
        "/admin/food",
        "/admin/categories",
        "/admin/students",
        "/admin/inventory",
        "/admin/reports",
        "/admin/settings",
        "/admin/notifications",
    ]:
        resp = student.get(path)
        assert resp.status_code == 403, f"{path} must be admin-only"


def test_admin_routes_redirect_anonymous(client):
    resp = client.get("/admin/")
    assert resp.status_code == 302
    assert "/login" in resp.headers["Location"]


def test_admin_dashboard_allowed(admin):
    resp = admin.get("/admin/")
    assert resp.status_code == 200


def test_profile_update(student, app):
    resp = student.post(
        "/profile",
        data={
            "full_name": "Updated Name",
            "email": "student@test.edu",
            "roll_number": "TYCS-999",
            "phone": "9876500000",
        },
        follow_redirects=True,
    )
    assert resp.status_code == 200
    user = User.query.filter_by(email="student@test.edu").first()
    assert user.full_name == "Updated Name"
    assert user.phone == "9876500000"


def test_change_password(student, app):
    resp = student.post(
        "/profile/password",
        data={
            "current_password": "Password123",
            "new_password": "NewSecret456",
            "confirm_password": "NewSecret456",
        },
        follow_redirects=False,
    )
    assert resp.status_code == 302
    student.post("/logout")
    resp = student.post(
        "/login",
        data={"email": "student@test.edu", "password": "NewSecret456"},
        follow_redirects=False,
    )
    assert resp.status_code == 302


def test_change_password_wrong_current(student):
    resp = student.post(
        "/profile/password",
        data={
            "current_password": "not-right",
            "new_password": "NewSecret456",
            "confirm_password": "NewSecret456",
        },
        follow_redirects=True,
    )
    assert b"incorrect" in resp.data.lower()
