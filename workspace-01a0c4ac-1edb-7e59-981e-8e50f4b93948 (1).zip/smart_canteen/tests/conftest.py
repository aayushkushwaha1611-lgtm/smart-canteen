"""Pytest fixtures: app, client, registered users, sample catalog.

Admin and student fixtures each own an independent test client (separate
sessions) so tests can act as both roles at once.
"""
import pytest

from app import create_app, db
from app.models import Category, FoodItem, User
from config import TestingConfig

STUDENT_DATA = {
    "full_name": "Test Student",
    "email": "student@test.edu",
    "roll_number": "TYCS-999",
    "phone": "9876543210",
    "password": "Password123",
    "confirm_password": "Password123",
    "accept_terms": "y",
}

ADMIN_DATA = {
    "full_name": "Test Admin",
    "email": "admin@test.edu",
    "roll_number": "ADMIN-9",
    "password": "Password123",
    "confirm_password": "Password123",
    "accept_terms": "y",
}


@pytest.fixture()
def app():
    app = create_app(TestingConfig)
    with app.app_context():
        db.create_all()
        # minimal catalog shared by most tests
        cat = Category(name="Breakfast", slug="breakfast")
        db.session.add(cat)
        db.session.flush()
        for name, price, stock in [
            ("Masala Dosa", 70, 10),
            ("Poha", 35, 5),
            ("Idli", 30, 3),
        ]:
            db.session.add(
                FoodItem(
                    name=name,
                    slug=name.lower().replace(" ", "-"),
                    description=f"{name} description",
                    category_id=cat.id,
                    price=price,
                    prep_time_minutes=10,
                    stock_quantity=stock,
                    low_stock_threshold=2,
                    is_available=True,
                    is_active=True,
                )
            )
        db.session.commit()
        yield app
        db.session.remove()
        db.drop_all()


@pytest.fixture()
def client(app):
    """Anonymous client (separate session from student/admin)."""
    return app.test_client()


@pytest.fixture()
def student(app):
    """Registered, logged-in student on its own client session."""
    c = app.test_client()
    c.post("/register", data=STUDENT_DATA, follow_redirects=False)
    return c


@pytest.fixture()
def student_model(app):
    return User.query.filter_by(email="student@test.edu").first()


@pytest.fixture()
def admin(app):
    """Registered user promoted to admin, signed in on its own client."""
    c = app.test_client()
    c.post("/register", data=ADMIN_DATA, follow_redirects=False)
    user = User.query.filter_by(email="admin@test.edu").first()
    user.role = "admin"
    db.session.commit()
    c.post("/logout")
    c.post("/login", data={"email": "admin@test.edu", "password": "Password123"})
    return c


@pytest.fixture()
def foods(app):
    return {f.slug: f for f in FoodItem.query.all()}
