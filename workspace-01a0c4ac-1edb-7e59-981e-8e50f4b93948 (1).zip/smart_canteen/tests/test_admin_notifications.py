"""Tests: admin dashboard, inventory, students, reports and notifications."""


def test_admin_dashboard_stats(admin):
    resp = admin.get("/admin/")
    assert resp.status_code == 200
    assert b"Total students" in resp.data
    assert b"Today" in resp.data


def test_inventory_lists_items(admin):
    resp = admin.get("/admin/inventory")
    assert resp.status_code == 200
    assert b"Masala Dosa" in resp.data


def test_inventory_update_stock(admin, foods, app):
    food = foods["poha"]
    resp = admin.post(
        f"/admin/inventory/{food.id}/update",
        data={
            "stock_quantity": 25,
            "low_stock_threshold": 4,
            "is_available": "y",
        },
        follow_redirects=True,
    )
    assert resp.status_code == 200
    from app import db

    db.session.refresh(food)
    assert food.stock_quantity == 25
    assert food.low_stock_threshold == 4


def test_inventory_never_negative(admin, foods, app):
    food = foods["poha"]
    admin.post(
        f"/admin/inventory/{food.id}/update",
        data={"stock_quantity": -50, "low_stock_threshold": 2},
        follow_redirects=True,
    )
    from app import db

    db.session.refresh(food)
    assert food.stock_quantity >= 0


def test_stock_status_labels(admin, foods):
    from app.models import FoodItem

    f = foods["poha"]
    f.stock_quantity = 10
    f.low_stock_threshold = 2
    assert f.stock_status == "in_stock"
    f.stock_quantity = 2
    assert f.stock_status == "low_stock"
    f.stock_quantity = 0
    assert f.stock_status == "out_of_stock"


def test_low_stock_shows_on_dashboard(admin, foods, app):
    food = foods["idli"]  # stock 3, threshold 2 → fine
    food.stock_quantity = 1
    from app import db

    db.session.commit()
    resp = admin.get("/admin/")
    assert b"Low-stock" in resp.data or b"low" in resp.data


def test_students_list_and_search(admin, student):
    resp = admin.get("/admin/students")
    assert resp.status_code == 200
    assert b"Test Student" in resp.data
    resp = admin.get("/admin/students?q=student@test.edu")
    assert b"Test Student" in resp.data
    resp = admin.get("/admin/students?q=nomatch-xyz")
    assert b"Test Student" not in resp.data


def test_student_detail_and_deactivate(admin, student, app):
    from app import db
    from app.models import User

    student_user = User.query.filter_by(email="student@test.edu").first()
    resp = admin.get(f"/admin/students/{student_user.id}")
    assert resp.status_code == 200
    admin.post(f"/admin/students/{student_user.id}/toggle", follow_redirects=True)
    db.session.refresh(student_user)
    assert student_user.is_active is False
    # deactivated student cannot use protected pages
    resp = student.get("/cart")
    assert resp.status_code in (302, 403)


def test_cannot_deactivate_self(admin, app):
    """Admin accounts are not students — the student toggle must refuse (404)."""
    from app.models import User

    me = User.query.filter_by(email="admin@test.edu").first()
    resp = admin.post(f"/admin/students/{me.id}/toggle", follow_redirects=False)
    assert resp.status_code == 404
    assert me.is_active is True


def test_reports_page_and_charts_data(admin):
    resp = admin.get("/admin/reports")
    assert resp.status_code == 200
    assert b"Daily orders" in resp.data
    assert b"chart-daily" in resp.data


def test_reports_csv_export(admin):
    for report in [
        "daily_orders",
        "weekly_orders",
        "monthly_orders",
        "popular_items",
        "category_performance",
        "order_statuses",
        "orders",
    ]:
        resp = admin.get(
            f"/admin/reports/export?report={report}&start=2026-01-01&end=2026-12-31"
        )
        assert resp.status_code == 200
        assert resp.mimetype == "text/csv"
        assert len(resp.data) > 10


def test_reports_date_filter(admin):
    resp = admin.get("/admin/reports?start=2026-09-01&end=2026-09-21&report=monthly_orders")
    assert resp.status_code == 200


def test_settings_update(admin, app):
    resp = admin.post(
        "/admin/settings",
        data={
            "canteen_name": "Campus Bites",
            "pickup_location": "Block C Counter",
            "pickup_message": "Be on time!",
            "cancel_window_minutes": 15,
            "low_stock_default": 6,
        },
        follow_redirects=True,
    )
    assert resp.status_code == 200
    from app.services.settings_service import SettingsService

    assert SettingsService.get("canteen_name") == "Campus Bites"
    assert SettingsService.get_int("cancel_window_minutes", 0) == 15


def test_notification_created_on_order_flow(student, foods, app):
    from app.models import Notification, Order

    student.post("/cart/add", data={"food_id": foods["poha"].id, "quantity": 1})
    student.post("/checkout", data={"confirm": "y"}, follow_redirects=True)
    order = Order.query.first()
    mine = Notification.query.filter_by(user_id=order.user_id).all()
    assert len(mine) >= 1


def test_notifications_page_and_mark_read(student, foods, app):
    from app.models import Notification

    student.post("/cart/add", data={"food_id": foods["poha"].id, "quantity": 1})
    student.post("/checkout", data={"confirm": "y"}, follow_redirects=True)
    resp = student.get("/notifications")
    assert resp.status_code == 200

    n = Notification.query.filter_by(is_read=False).first()
    assert n is not None
    student.post(f"/notifications/{n.id}/read", follow_redirects=True)
    from app import db

    db.session.refresh(n)
    assert n.is_read is True


def test_mark_all_read(student, foods, app):
    from app.models import Notification

    student.post("/cart/add", data={"food_id": foods["poha"].id, "quantity": 1})
    student.post("/checkout", data={"confirm": "y"}, follow_redirects=True)
    student.post("/notifications/read-all", follow_redirects=True)
    assert Notification.query.filter_by(is_read=False).count() == 0


def test_unread_count_api(student, foods):
    student.post("/cart/add", data={"food_id": foods["poha"].id, "quantity": 1})
    student.post("/checkout", data={"confirm": "y"}, follow_redirects=True)
    resp = student.get("/api/notifications/unread-count")
    assert resp.is_json
    assert resp.get_json()["count"] >= 1


def test_admin_gets_low_stock_notification_on_restock(admin, foods, app):
    from app.models import Notification

    food = foods["idli"]
    admin.post(
        f"/admin/inventory/{food.id}/update",
        data={"stock_quantity": 1, "low_stock_threshold": 5},
        follow_redirects=True,
    )
    low = Notification.query.filter_by(type="low_stock").all()
    assert len(low) >= 1


def test_error_pages_render(client):
    assert client.get("/does-not-exist").status_code == 404
