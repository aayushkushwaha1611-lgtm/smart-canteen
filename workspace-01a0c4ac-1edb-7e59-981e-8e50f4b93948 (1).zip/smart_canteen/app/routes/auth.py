"""Authentication routes: register, login, logout, profile management."""
from flask import Blueprint, flash, redirect, render_template, request, url_for
from flask_login import current_user, login_required, login_user, logout_user

from app import db
from app.forms.auth_forms import ChangePasswordForm, LoginForm, ProfileForm, RegisterForm
from app.models.user import User
from app.services.notification_service import NotificationService
from app.utils.helpers import log_activity

bp = Blueprint("auth", __name__)


def _redirect_after_login(user):
    nxt = request.args.get("next") or request.form.get("next")
    # Only allow same-site relative redirects (open-redirect protection).
    if nxt and nxt.startswith("/") and not nxt.startswith("//") and nxt != request.path:
        return redirect(nxt)
    return redirect(url_for("admin.dashboard") if user.is_admin else url_for("main.dashboard"))


@bp.route("/register", methods=["GET", "POST"])
def register():
    if current_user.is_authenticated:
        return _redirect_after_login(current_user)

    form = RegisterForm()
    if form.validate_on_submit():
        user = User(
            full_name=form.full_name.data.strip(),
            email=form.email.data.lower().strip(),
            roll_number=form.roll_number.data.strip().upper(),
            phone=(form.phone.data or "").strip() or None,
            role="student",
        )
        user.set_password(form.password.data)
        db.session.add(user)
        db.session.flush()
        log_activity("register", "user", user.id, f"New student: {user.email}")
        NotificationService.send(
            user,
            "Welcome to Smart Canteen! 🎉",
            "Your account is ready. Browse today's menu and place your first order to get a digital token.",
            "account",
            link="/dashboard",
            commit=True,
        )
        login_user(user)
        flash("Account created successfully. Welcome aboard!", "success")
        return redirect(url_for("main.dashboard"))

    return render_template("auth/register.html", form=form)


@bp.route("/login", methods=["GET", "POST"])
def login():
    if current_user.is_authenticated:
        return _redirect_after_login(current_user)

    form = LoginForm()
    if form.validate_on_submit():
        email = form.email.data.lower().strip()
        user = User.query.filter_by(email=email).first()
        if user is None or not user.check_password(form.password.data):
            flash("Invalid email or password.", "danger")
            log_activity("login_failed", "user", user.id if user else None, f"Failed login for {email}")
            db.session.commit()
            return render_template("auth/login.html", form=form), 401

        if not user.is_active:
            flash("Your account has been deactivated. Contact the canteen administrator.", "danger")
            return render_template("auth/login.html", form=form), 403

        login_user(user, remember=form.remember.data)
        log_activity("login", "user", user.id, f"{user.email} signed in")
        db.session.commit()
        flash(f"Welcome back, {user.full_name.split()[0]}!", "success")
        return _redirect_after_login(user)

    return render_template("auth/login.html", form=form)


@bp.route("/logout", methods=["POST"])
@login_required
def logout():
    log_activity("logout", "user", current_user.id)
    db.session.commit()
    logout_user()
    flash("You have been signed out.", "info")
    return redirect(url_for("main.home"))


@bp.route("/profile", methods=["GET", "POST"])
@login_required
def profile():
    form = ProfileForm(current_user, obj=current_user)
    if form.validate_on_submit():
        current_user.full_name = form.full_name.data.strip()
        current_user.email = form.email.data.lower().strip()
        current_user.roll_number = form.roll_number.data.strip().upper()
        current_user.phone = (form.phone.data or "").strip() or None
        log_activity("profile_update", "user", current_user.id)
        db.session.commit()
        flash("Profile updated successfully.", "success")
        return redirect(url_for("auth.profile"))

    password_form = ChangePasswordForm()
    return render_template(
        "auth/profile.html", form=form, password_form=password_form
    )


@bp.route("/profile/password", methods=["POST"])
@login_required
def change_password():
    password_form = ChangePasswordForm()
    if password_form.validate_on_submit():
        if not current_user.check_password(password_form.current_password.data):
            password_form.current_password.errors.append("Current password is incorrect.")
        else:
            current_user.set_password(password_form.new_password.data)
            log_activity("password_change", "user", current_user.id)
            db.session.commit()
            flash("Password changed successfully.", "success")
            return redirect(url_for("auth.profile"))

    profile_form = ProfileForm(current_user, obj=current_user)
    return render_template(
        "auth/profile.html", form=profile_form, password_form=password_form
    ), 400
