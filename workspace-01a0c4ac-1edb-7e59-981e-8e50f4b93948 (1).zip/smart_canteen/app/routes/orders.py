"""Student order routes - history, tracking, confirmation, cancellation."""
from flask import Blueprint, abort, flash, redirect, render_template, request, url_for
from flask_login import current_user, login_required

from app.models.order import Order
from app.services.order_service import OrderError, OrderService

bp = Blueprint("orders", __name__)


def _get_visible_order(order_id: int) -> Order:
    order = db_get(order_id)
    if order.user_id != current_user.id and not current_user.is_admin:
        abort(403, description="You can only view your own orders.")
    return order


def db_get(order_id: int) -> Order:
    from app import db

    order = db.session.get(Order, order_id)
    if order is None:
        abort(404, description="Order not found.")
    return order


@bp.route("/orders")
@login_required
def history():
    page = max(1, request.args.get("page", 1, type=int))
    status = request.args.get("status", "").strip()
    query = Order.query.filter_by(user_id=current_user.id)
    if status:
        query = query.filter_by(status=status)
    pagination = query.order_by(Order.created_at.desc()).paginate(
        page=page, per_page=10, error_out=False
    )
    return render_template("orders/list.html", pagination=pagination, status=status)


@bp.route("/orders/<int:order_id>")
@login_required
def detail(order_id):
    order = _get_visible_order(order_id)
    can_cancel, cancel_reason = (False, "")
    if not current_user.is_admin:
        can_cancel, cancel_reason = OrderService.can_student_cancel(order)
    elif order.is_cancellable:
        can_cancel, cancel_reason = True, "OK"
    return render_template(
        "orders/detail.html",
        order=order,
        can_cancel=can_cancel,
        cancel_reason=cancel_reason,
    )


@bp.route("/orders/<int:order_id>/confirmation")
@login_required
def confirmation(order_id):
    order = db_get(order_id)
    if order.user_id != current_user.id:
        abort(403, description="You can only view your own orders.")
    return render_template("orders/confirmation.html", order=order)


@bp.route("/orders/<int:order_id>/cancel", methods=["POST"])
@login_required
def cancel(order_id):
    order = db_get(order_id)
    if order.user_id != current_user.id and not current_user.is_admin:
        abort(403, description="You can only cancel your own orders.")

    if not current_user.is_admin:
        can_cancel, reason = OrderService.can_student_cancel(order)
        if not can_cancel:
            flash(reason, "warning")
            return redirect(url_for("orders.detail", order_id=order.id))

    note = (request.form.get("reason") or "").strip()
    try:
        OrderService.cancel_order(
            order,
            current_user,
            is_admin=current_user.is_admin,
            reason=note or ("Cancelled by student" if order.user_id == current_user.id else "Cancelled by admin"),
        )
        flash("Order cancelled. Reserved stock has been restored.", "success")
    except OrderError as exc:
        flash(str(exc), "danger")
    return redirect(url_for("orders.detail", order_id=order.id))
