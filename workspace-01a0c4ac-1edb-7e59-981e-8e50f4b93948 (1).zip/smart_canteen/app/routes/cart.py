"""Cart routes - page + AJAX endpoints (progressive enhancement).

Every endpoint works as a classic form POST (redirect + flash) and as a
fetch() JSON call used by the live cart UI.
"""
from flask import Blueprint, flash, jsonify, redirect, render_template, request, url_for
from flask_login import current_user, login_required

from app.services.cart_service import CartService

bp = Blueprint("cart", __name__)


def _wants_json() -> bool:
    return (
        request.headers.get("X-Requested-With") == "fetch"
        or request.accept_mimetypes.best == "application/json"
    )


def _payload(ok: bool, message: str, redirect_to: str | None = None):
    cart = CartService.get_or_create(current_user)
    data = {
        "ok": ok,
        "message": message,
        "cart_count": CartService.item_count(current_user),
        "subtotal": CartService.subtotal(cart),
        "lines": [
            {
                "id": line.id,
                "name": line.food_item.name,
                "quantity": line.quantity,
                "price": float(line.food_item.price),
                "line_total": line.line_total,
                "stock": line.food_item.stock_quantity,
            }
            for line in cart.items
            if line.food_item
        ],
    }
    if _wants_json():
        return jsonify(data), (200 if ok else 400)
    flash(message, "success" if ok else "warning")
    return redirect(redirect_to or request.referrer or url_for("cart.index"))


def _int_arg(*names):
    for name in names:
        value = request.values.get(name, type=int)
        if value:
            return value
    json_data = request.get_json(silent=True) or {}
    for name in names:
        value = json_data.get(name)
        if isinstance(value, int):
            return value
    return None


@bp.route("/cart")
@login_required
def index():
    cart = CartService.get_or_create(current_user)
    return render_template(
        "cart/index.html", cart=cart, subtotal=CartService.subtotal(cart)
    )


@bp.route("/cart/add", methods=["POST"])
@login_required
def add():
    food_id = _int_arg("food_id", "item_id")
    quantity = request.values.get("quantity", default=1, type=int) or 1
    if not food_id:
        return _payload(False, "Invalid item.", url_for("menu.index"))
    ok, message = CartService.add(current_user, food_id, quantity)
    return _payload(ok, message, url_for("menu.index"))


@bp.route("/cart/item/<int:item_id>/update", methods=["POST"])
@login_required
def update(item_id):
    quantity = request.values.get("quantity", type=int)
    action = request.values.get("action", "")
    if quantity is None:
        if action == "inc":
            ok, message = CartService.increment(current_user, item_id)
        elif action == "dec":
            ok, message = CartService.decrement(current_user, item_id)
        else:
            ok, message = False, "Invalid cart action."
    else:
        ok, message = CartService.update_quantity(current_user, item_id, quantity)
    return _payload(ok, message)


@bp.route("/cart/item/<int:item_id>/remove", methods=["POST"])
@login_required
def remove(item_id):
    ok, message = CartService.remove(current_user, item_id)
    return _payload(ok, message)


@bp.route("/cart/clear", methods=["POST"])
@login_required
def clear():
    ok, message = CartService.clear(current_user)
    return _payload(ok, message)
