"""Menu browsing: search, category / price filters, sorting, details."""
from flask import Blueprint, abort, render_template, request

from app import db
from app.models.food import FoodItem
from app.services.menu_service import MenuService

bp = Blueprint("menu", __name__)

SORT_OPTIONS = {
    "popular": "Most Popular",
    "price_asc": "Price: Low → High",
    "price_desc": "Price: High → Low",
    "name": "Name (A → Z)",
    "newest": "Newest First",
}


def _num(value):
    try:
        return float(value) if value not in (None, "") else None
    except (TypeError, ValueError):
        return None


def _menu_page(category_slug=None):
    q = (request.args.get("q") or "").strip() or None
    min_price = _num(request.args.get("min_price"))
    max_price = _num(request.args.get("max_price"))
    sort = request.args.get("sort", "popular")
    if sort not in SORT_OPTIONS:
        sort = "popular"
    page = max(1, request.args.get("page", 1, type=int))

    if min_price is not None and max_price is not None and min_price > max_price:
        min_price, max_price = max_price, min_price

    query = MenuService.menu_query(
        q=q,
        category_slug=category_slug,
        min_price=min_price,
        max_price=max_price,
        sort=sort,
    )
    pagination = query.paginate(page=page, per_page=9, error_out=False)

    active_category = None
    if category_slug:
        from app.models.category import Category

        active_category = Category.query.filter_by(slug=category_slug).first_or_404()

    return render_template(
        "menu/index.html",
        pagination=pagination,
        items=pagination.items,
        categories=MenuService.active_categories(),
        active_category=active_category,
        q=q or "",
        min_price=min_price if min_price is not None else "",
        max_price=max_price if max_price is not None else "",
        sort=sort,
        sort_options=SORT_OPTIONS,
    )


@bp.route("/menu")
def index():
    return _menu_page(request.args.get("category") or None)


@bp.route("/menu/category/<slug>")
def by_category(slug):
    return _menu_page(category_slug=slug)


@bp.route("/food/<int:item_id>")
def detail(item_id):
    food = db.session.get(FoodItem, item_id)
    if food is None or not food.is_active:
        abort(404, description="Food item not found.")
    related = (
        FoodItem.query.filter(
            FoodItem.category_id == food.category_id,
            FoodItem.id != food.id,
            FoodItem.is_active.is_(True),
        )
        .limit(4)
        .all()
    )
    return render_template("menu/detail.html", food=food, related=related)
