"""Checkout route - review + confirm the order (server-side totals)."""
from flask import Blueprint, abort, flash, redirect, render_template, url_for
from flask_login import current_user, login_required

from app.forms.order_forms import CheckoutForm
from app.services.cart_service import CartService
from app.services.order_service import OrderError, OrderService
from app.services.settings_service import SettingsService

bp = Blueprint("checkout", __name__)


@bp.route("/checkout", methods=["GET", "POST"])
@login_required
def index():
    if not current_user.is_active:
        abort(403, description="This account has been deactivated.")

    form = CheckoutForm()
    ok, message, _lines = CartService.validate(current_user)
    if not ok:
        flash(message, "warning")
        return redirect(url_for("cart.index"))

    cart = CartService.get_or_create(current_user)
    subtotal = CartService.subtotal(cart)
    est_minutes = max(
        [int(line.food_item.prep_time_minutes or 10) for line in cart.items if line.food_item] or [10]
    )

    if form.validate_on_submit():
        try:
            order = OrderService.place_order(current_user, form.notes.data)
        except OrderError as exc:
            flash(str(exc), "danger")
            return redirect(url_for("checkout.index"))
        flash(f"Order placed! Your token is {order.token.token_number}.", "success")
        return redirect(url_for("orders.confirmation", order_id=order.id))

    settings = SettingsService.all()
    return render_template(
        "checkout/index.html",
        form=form,
        cart=cart,
        subtotal=subtotal,
        est_minutes=est_minutes,
        settings=settings,
    )
