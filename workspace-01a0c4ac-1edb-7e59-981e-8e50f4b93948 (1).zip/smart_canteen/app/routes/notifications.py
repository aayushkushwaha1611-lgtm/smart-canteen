"""In-app notification routes (student + admin share the model)."""
from flask import Blueprint, jsonify, redirect, render_template, request, url_for
from flask_login import current_user, login_required

from app.models.notification import Notification
from app.services.notification_service import NotificationService

bp = Blueprint("notifications", __name__)


@bp.route("/notifications")
@login_required
def index():
    page = max(1, request.args.get("page", 1, type=int))
    pagination = current_user.notifications.paginate(page=page, per_page=12, error_out=False)
    return render_template("notifications/index.html", pagination=pagination)


@bp.route("/notifications/<int:notification_id>/read", methods=["POST"])
@login_required
def mark_read(notification_id):
    notification = Notification.query.filter_by(
        id=notification_id, user_id=current_user.id
    ).first_or_404()
    if not notification.is_read:
        NotificationService.mark_read(notification)
    if request.headers.get("X-Requested-With") == "fetch":
        return jsonify(ok=True, unread=NotificationService.unread_count(current_user))
    return redirect(request.referrer or url_for("notifications.index"))


@bp.route("/notifications/read-all", methods=["POST"])
@login_required
def mark_all_read():
    count = NotificationService.mark_all_read(current_user)
    if request.headers.get("X-Requested-With") == "fetch":
        return jsonify(ok=True, unread=0, marked=count)
    return redirect(request.referrer or url_for("notifications.index"))


@bp.route("/api/notifications/unread-count")
@login_required
def unread_count():
    return jsonify(count=NotificationService.unread_count(current_user))
