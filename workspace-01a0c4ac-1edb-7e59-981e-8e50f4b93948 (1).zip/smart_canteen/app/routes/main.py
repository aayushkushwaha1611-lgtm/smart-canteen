"""Public + student home routes: landing page, dashboard, categories."""
from flask import Blueprint, redirect, render_template, url_for
from flask_login import current_user, login_required

from app.models.order import Order
from app.services.menu_service import MenuService
from app.services.order_service import OrderService

bp = Blueprint("main", __name__)


@bp.route("/")
def home():
    categories = MenuService.active_categories()
    popular = MenuService.popular_items(4)
    specials = MenuService.todays_specials(4)
    today_menu = MenuService.todays_menu(limit=6)
    return render_template(
        "main/home.html",
        categories=categories,
        popular_items=popular,
        special_items=specials,
        today_menu=today_menu,
    )


@bp.route("/dashboard")
@login_required
def dashboard():
    if current_user.is_admin:
        return redirect(url_for("admin.dashboard"))

    current_order = OrderService.current_order(current_user)
    recent_orders = (
        Order.query.filter_by(user_id=current_user.id)
        .order_by(Order.created_at.desc())
        .limit(5)
        .all()
    )
    return render_template(
        "student/dashboard.html",
        current_order=current_order,
        recent_orders=recent_orders,
        today_menu=MenuService.todays_menu(limit=4),
        popular_items=MenuService.popular_items(4),
        reordered=OrderService.recently_ordered_items(current_user, 4),
        notifications=current_user.notifications.limit(5).all(),
    )


@bp.route("/categories")
def categories():
    categories = MenuService.active_categories()
    counts = MenuService.category_counts()
    return render_template("main/categories.html", categories=categories, counts=counts)


@bp.route("/how-it-works")
def how_it_works():
    return render_template("main/how_it_works.html")
