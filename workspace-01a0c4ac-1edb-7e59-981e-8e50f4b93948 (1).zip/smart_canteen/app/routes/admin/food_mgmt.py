"""Admin food & category management (full CRUD + image upload)."""
from flask import abort, flash, redirect, render_template, request, url_for

from app import db
from app.forms.food_forms import CategoryForm, FoodForm
from app.models.category import Category
from app.models.food import FoodItem
from app.routes.admin import bp
from app.utils.helpers import delete_food_image, log_activity, save_food_image, unique_slug
from flask_login import current_user


# --------------------------------------------------------------------------
# Food items
# --------------------------------------------------------------------------
@bp.route("/food")
def food_list():
    page = max(1, request.args.get("page", 1, type=int))
    q = (request.args.get("q") or "").strip()
    category_id = request.args.get("category", type=int)

    query = FoodItem.query
    if q:
        query = query.filter(FoodItem.name.ilike(f"%{q}%"))
    if category_id:
        query = query.filter_by(category_id=category_id)
    pagination = query.order_by(FoodItem.name).paginate(page=page, per_page=10, error_out=False)
    return render_template(
        "admin/food_list.html",
        pagination=pagination,
        categories=Category.query.order_by(Category.sort_order).all(),
        q=q,
        category_id=category_id,
    )


def _save_image_field(form, food):
    """Handle optional photo upload/replacement. Returns static-relative path."""
    if not form.image.data or not getattr(form.image.data, "filename", ""):
        return food.image if food else None
    new_path = save_food_image(form.image.data)
    if food and food.image and food.image.startswith("uploads/"):
        delete_food_image(food.image)
    return new_path


@bp.route("/food/add", methods=["GET", "POST"])
def food_add():
    form = FoodForm()
    if form.validate_on_submit():
        food = FoodItem(
            name=form.name.data.strip(),
            slug=unique_slug(FoodItem, form.name.data),
            description=(form.description.data or "").strip(),
            category_id=form.category_id.data,
            price=round(float(form.price.data), 2),
            prep_time_minutes=form.prep_time_minutes.data,
            stock_quantity=max(form.stock_quantity.data, 0),
            low_stock_threshold=form.low_stock_threshold.data,
            is_available=form.is_available.data and form.stock_quantity.data > 0,
            is_active=form.is_active.data,
            is_special=form.is_special.data,
            image=_save_image_field(form, None),
        )
        db.session.add(food)
        log_activity("food_create", "food_item", None, food.name)
        db.session.commit()
        flash(f"'{food.name}' added to the menu.", "success")
        return redirect(url_for("admin.food_list"))
    return render_template("admin/food_form.html", form=form, food=None)


@bp.route("/food/<int:food_id>/edit", methods=["GET", "POST"])
def food_edit(food_id):
    food = db.session.get(FoodItem, food_id)
    if food is None:
        abort(404, description="Food item not found.")

    form = FoodForm(original=food, obj=food)
    if form.validate_on_submit():
        food.name = form.name.data.strip()
        food.description = (form.description.data or "").strip()
        food.category_id = form.category_id.data
        food.price = round(float(form.price.data), 2)
        food.prep_time_minutes = form.prep_time_minutes.data
        food.stock_quantity = max(form.stock_quantity.data, 0)
        food.low_stock_threshold = form.low_stock_threshold.data
        food.is_available = form.is_available.data and food.stock_quantity > 0
        food.is_active = form.is_active.data
        food.is_special = form.is_special.data
        food.image = _save_image_field(form, food)
        log_activity("food_update", "food_item", food.id, food.name)
        db.session.commit()
        flash(f"'{food.name}' updated.", "success")
        return redirect(url_for("admin.food_list"))

    return render_template("admin/food_form.html", form=form, food=food)


@bp.route("/food/<int:food_id>/toggle", methods=["POST"])
def food_toggle(food_id):
    food = db.session.get(FoodItem, food_id)
    if food is None:
        abort(404, description="Food item not found.")
    food.is_active = not food.is_active
    log_activity("food_toggle", "food_item", food.id,
                 f"{food.name} {'activated' if food.is_active else 'deactivated'}")
    db.session.commit()
    flash(
        f"'{food.name}' is now {'active' if food.is_active else 'inactive (deleted from menu)'}.",
        "success",
    )
    return redirect(request.referrer or url_for("admin.food_list"))


@bp.route("/food/<int:food_id>/availability", methods=["POST"])
def food_availability(food_id):
    food = db.session.get(FoodItem, food_id)
    if food is None:
        abort(404, description="Food item not found.")
    desired = request.form.get("available") == "1"
    if desired and food.stock_quantity <= 0:
        flash("Cannot enable availability when stock is zero. Restock first.", "warning")
    else:
        food.is_available = desired
        log_activity("food_availability", "food_item", food.id,
                     f"{food.name} availability → {desired}")
        db.session.commit()
        flash(f"'{food.name}' is {'available' if desired else 'unavailable'}.", "success")
    return redirect(request.referrer or url_for("admin.food_list"))


@bp.route("/food/<int:food_id>/delete", methods=["POST"])
def food_delete(food_id):
    """Soft-delete: deactivates the item (order history keeps its snapshots)."""
    food = db.session.get(FoodItem, food_id)
    if food is None:
        abort(404, description="Food item not found.")
    food.is_active = False
    food.is_available = False
    log_activity("food_delete", "food_item", food.id, food.name)
    db.session.commit()
    flash(f"'{food.name}' removed from the menu.", "success")
    return redirect(url_for("admin.food_list"))


# --------------------------------------------------------------------------
# Categories
# --------------------------------------------------------------------------
@bp.route("/categories", methods=["GET", "POST"])
def categories():
    form = CategoryForm()
    if form.validate_on_submit():
        category = Category(
            name=form.name.data.strip(),
            slug=unique_slug(Category, form.name.data),
            description=(form.description.data or "").strip(),
            sort_order=form.sort_order.data or 0,
            is_active=form.is_active.data,
        )
        db.session.add(category)
        log_activity("category_create", "category", None, category.name)
        db.session.commit()
        flash(f"Category '{category.name}' created.", "success")
        return redirect(url_for("admin.categories"))

    items = Category.query.order_by(Category.sort_order, Category.name).all()
    return render_template("admin/categories.html", form=form, categories=items)


@bp.route("/categories/<int:category_id>/edit", methods=["GET", "POST"])
def category_edit(category_id):
    category = db.session.get(Category, category_id)
    if category is None:
        abort(404, description="Category not found.")

    form = CategoryForm(original=category, obj=category)
    if form.validate_on_submit():
        category.name = form.name.data.strip()
        category.description = (form.description.data or "").strip()
        category.sort_order = form.sort_order.data or 0
        category.is_active = form.is_active.data
        log_activity("category_update", "category", category.id, category.name)
        db.session.commit()
        flash(f"Category '{category.name}' updated.", "success")
        return redirect(url_for("admin.categories"))

    return render_template("admin/category_form.html", form=form, category=category)


@bp.route("/categories/<int:category_id>/toggle", methods=["POST"])
def category_toggle(category_id):
    category = db.session.get(Category, category_id)
    if category is None:
        abort(404, description="Category not found.")
    category.is_active = not category.is_active
    log_activity("category_toggle", "category", category.id,
                 f"{category.name} → active={category.is_active}")
    db.session.commit()
    flash(f"Category '{category.name}' is now {'active' if category.is_active else 'inactive'}.", "success")
    return redirect(url_for("admin.categories"))
