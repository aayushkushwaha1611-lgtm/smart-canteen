"""Admin order management: table, filters and kitchen status actions."""
from flask import abort, flash, redirect, render_template, request, url_for

from app import db
from app.models.order import Order, OrderStatus
from app.models.user import User
from app.routes.admin import bp
from app.services.order_service import OrderError, OrderService
from app.utils.helpers import log_activity


@bp.route("/orders")
def orders():
    page = max(1, request.args.get("page", 1, type=int))
    status = (request.args.get("status") or "").strip()
    q = (request.args.get("q") or "").strip()
    date_from = (request.args.get("date_from") or "").strip()

    query = Order.query
    if status in OrderStatus.ALL:
        query = query.filter_by(status=status)
    if q:
        like = f"%{q}%"
        query = query.join(User).filter(
            db.or_(
                Order.order_number.ilike(like),
                User.full_name.ilike(like),
                User.email.ilike(like),
                User.roll_number.ilike(like),
            )
        )
    if date_from:
        from datetime import datetime

        try:
            day = datetime.strptime(date_from, "%Y-%m-%d")
            query = query.filter(Order.created_at >= day)
        except ValueError:
            pass

    pagination = query.order_by(Order.created_at.desc()).paginate(
        page=page, per_page=10, error_out=False
    )
    return render_template(
        "admin/orders.html",
        pagination=pagination,
        status=status,
        q=q,
        date_from=date_from,
    )


@bp.route("/orders/<int:order_id>")
def order_detail(order_id):
    order = db.session.get(Order, order_id)
    if order is None:
        abort(404, description="Order not found.")
    history = order.status_history.all()
    return render_template("admin/order_detail.html", order=order, history=history)


@bp.route("/orders/<int:order_id>/status", methods=["POST"])
def update_status(order_id):
    order = db.session.get(Order, order_id)
    if order is None:
        abort(404, description="Order not found.")

    action = (request.form.get("action") or "").strip()
    note = (request.form.get("note") or "").strip() or None
    from flask_login import current_user

    try:
        OrderService.change_status(order, action, current_user, note=note)
        flash(
            f"{order.order_number} → {OrderStatus.label(order.status)}.",
            "success",
        )
    except OrderError as exc:
        flash(str(exc), "danger")

    if request.form.get("return") == "list":
        return redirect(url_for("admin.orders"))
    return redirect(url_for("admin.order_detail", order_id=order.id))
