"""Admin blueprint - separate, strictly role-protected management panel."""
from flask import Blueprint, abort, redirect, request, url_for
from flask_login import current_user

bp = Blueprint("admin", __name__, url_prefix="/admin")


@bp.before_request
def protect_admin_panel():
    """Every /admin route requires an authenticated, active administrator."""
    if not current_user.is_authenticated:
        return redirect(url_for("auth.login", next=request.path))
    if not current_user.is_active:
        abort(403, description="This account has been deactivated.")
    if current_user.role != "admin":
        abort(403, description="Administrator access only.")


# Attach all admin views to the blueprint before it gets registered.
from app.routes.admin import dashboard, order_mgmt, food_mgmt, students, inventory, reports  # noqa: E402,F401
