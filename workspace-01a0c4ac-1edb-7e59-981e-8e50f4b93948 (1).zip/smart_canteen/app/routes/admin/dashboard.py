"""Admin dashboard, settings and admin notifications."""
from flask import flash, redirect, render_template, request, url_for

from app import db
from app.forms.order_forms import SettingsForm
from app.models.activity import ActivityLog
from app.models.order import Order
from app.models.notification import Notification
from app.routes.admin import bp
from app.services.notification_service import NotificationService
from app.services.report_service import ReportService
from app.services.settings_service import SettingsService
from app.utils.helpers import log_activity


@bp.route("/")
def dashboard():
    stats = ReportService.dashboard_stats()
    recent_orders = Order.query.order_by(Order.created_at.desc()).limit(8).all()
    recent_activity = ActivityLog.query.order_by(ActivityLog.created_at.desc()).limit(12).all()
    return render_template(
        "admin/dashboard.html",
        stats=stats,
        recent_orders=recent_orders,
        recent_activity=recent_activity,
    )


@bp.route("/settings", methods=["GET", "POST"])
def settings():
    form = SettingsForm()
    if form.validate_on_submit():
        SettingsService.update_from_form(form)
        log_activity("settings_update", "settings", None)
        db.session.commit()
        flash("Settings saved.", "success")
        return redirect(url_for("admin.settings"))

    if not form.is_submitted():
        values = SettingsService.all()
        form.canteen_name.data = values["canteen_name"]
        form.pickup_location.data = values["pickup_location"]
        form.pickup_message.data = values["pickup_message"]
        form.cancel_window_minutes.data = int(values.get("cancel_window_minutes", 10))
        form.low_stock_default.data = int(values.get("low_stock_default", 5))
    return render_template("admin/settings.html", form=form)


@bp.route("/notifications")
def notifications():
    page = max(1, request.args.get("page", 1, type=int))
    pagination = current_user_notifications(page)
    return render_template("admin/notifications.html", pagination=pagination)


def current_user_notifications(page: int):
    return Notification.query.filter_by(user_id=current_user_id()).order_by(
        Notification.created_at.desc()
    ).paginate(page=page, per_page=12, error_out=False)


def current_user_id():
    from flask_login import current_user

    return current_user.id


@bp.route("/notifications/<int:notification_id>/read", methods=["POST"])
def mark_read(notification_id):
    notification = Notification.query.filter_by(
        id=notification_id, user_id=current_user_id()
    ).first_or_404()
    if not notification.is_read:
        NotificationService.mark_read(notification)
    return redirect(request.referrer or url_for("admin.notifications"))


@bp.route("/notifications/read-all", methods=["POST"])
def mark_all_read():
    from flask_login import current_user

    NotificationService.mark_all_read(current_user)
    return redirect(request.referrer or url_for("admin.notifications"))
