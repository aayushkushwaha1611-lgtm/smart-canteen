"""Admin student management: list, search, details, activate/deactivate."""
from flask import abort, flash, redirect, render_template, request, url_for

from app import db
from app.models.order import Order, OrderStatus
from app.models.user import User
from app.routes.admin import bp
from app.services.notification_service import NotificationService
from app.utils.helpers import log_activity
from flask_login import current_user


@bp.route("/students")
def students():
    page = max(1, request.args.get("page", 1, type=int))
    q = (request.args.get("q") or "").strip()
    status = (request.args.get("status") or "").strip()

    query = User.query.filter_by(role="student")
    if q:
        like = f"%{q}%"
        query = query.filter(
            db.or_(
                User.full_name.ilike(like),
                User.email.ilike(like),
                User.roll_number.ilike(like),
            )
        )
    if status == "active":
        query = query.filter_by(is_active=True)
    elif status == "inactive":
        query = query.filter_by(is_active=False)

    pagination = query.order_by(User.created_at.desc()).paginate(
        page=page, per_page=12, error_out=False
    )
    return render_template("admin/students.html", pagination=pagination, q=q, status=status)


@bp.route("/students/<int:student_id>")
def student_detail(student_id):
    student = db.session.get(User, student_id)
    if student is None or student.role != "student":
        abort(404, description="Student not found.")

    page = max(1, request.args.get("page", 1, type=int))
    orders_pagination = (
        Order.query.filter_by(user_id=student.id)
        .order_by(Order.created_at.desc())
        .paginate(page=page, per_page=10, error_out=False)
    )
    total_orders = Order.query.filter_by(user_id=student.id).count()
    completed = Order.query.filter_by(user_id=student.id, status=OrderStatus.COMPLETED).count()
    cancelled = Order.query.filter_by(user_id=student.id, status=OrderStatus.CANCELLED).count()
    spent = sum(
        float(o.total_amount)
        for o in Order.query.filter(
            Order.user_id == student.id, Order.status == OrderStatus.COMPLETED
        ).all()
    )
    return render_template(
        "admin/student_detail.html",
        student=student,
        orders_pagination=orders_pagination,
        stats={
            "total_orders": total_orders,
            "completed": completed,
            "cancelled": cancelled,
            "spent": round(spent, 2),
        },
    )


@bp.route("/students/<int:student_id>/toggle", methods=["POST"])
def student_toggle(student_id):
    student = db.session.get(User, student_id)
    if student is None or student.role != "student":
        abort(404, description="Student not found.")
    if student.id == current_user.id:
        flash("You cannot deactivate your own account.", "warning")
        return redirect(url_for("admin.student_detail", student_id=student.id))

    student.is_active = not student.is_active
    log_activity(
        "student_toggle",
        "user",
        student.id,
        f"{student.email} → {'active' if student.is_active else 'deactivated'}",
    )
    NotificationService.send(
        student,
        "Account update 👤",
        "Your account has been "
        + ("reactivated. You can order again!" if student.is_active else "deactivated. Contact the canteen desk if this is a mistake."),
        "account",
        commit=False,
    )
    db.session.commit()
    flash(
        f"{student.full_name}'s account is now {'active' if student.is_active else 'deactivated'}.",
        "success",
    )
    return redirect(url_for("admin.student_detail", student_id=student.id))
