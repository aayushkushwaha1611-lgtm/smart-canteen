"""Admin reports: charts, date filtering and CSV export."""
from datetime import date, datetime, timedelta

from flask import Response, abort, render_template, request

from app.models.order import OrderStatus
from app.routes.admin import bp
from app.services.report_service import ReportService

REPORT_NAMES = {
    "daily_orders": "Daily Orders & Revenue",
    "weekly_orders": "Weekly Orders & Revenue",
    "monthly_orders": "Monthly Orders & Revenue",
    "popular_items": "Popular Food Items",
    "category_performance": "Category Performance",
    "order_statuses": "Order Status Summary",
    "orders": "Full Order List",
}


def _parse_date(value: str | None, default: date) -> date:
    if not value:
        return default
    try:
        return datetime.strptime(value, "%Y-%m-%d").date()
    except ValueError:
        return default


def _range_from_request():
    today = datetime.now().date()
    start = _parse_date(request.args.get("start"), today - timedelta(days=29))
    end = _parse_date(request.args.get("end"), today)
    if start > end:
        start, end = end, start
    return start, end


@bp.route("/reports")
def reports():
    start, end = _range_from_request()
    report = request.args.get("report", "daily_orders")
    if report not in REPORT_NAMES:
        report = "daily_orders"

    data = {
        "daily": ReportService.daily_series(start, end),
        "weekly": ReportService.weekly_series(start, end),
        "monthly": ReportService.monthly_series(start, end),
        "popular": ReportService.popular_items(8, start, end),
        "categories": ReportService.category_performance(start, end),
        "statuses": ReportService.status_summary(start, end),
        "revenue": ReportService.revenue_totals(start, end),
    }
    return render_template(
        "admin/reports.html",
        data=data,
        start=start.isoformat(),
        end=end.isoformat(),
        report=report,
        report_names=REPORT_NAMES,
        status_labels=OrderStatus.LABELS,
    )


@bp.route("/reports/export")
def export_csv():
    start, end = _range_from_request()
    report = request.args.get("report", "daily_orders")
    if report not in REPORT_NAMES:
        abort(400, description="Unknown report.")

    csv_text = ReportService.csv_report(report, start, end)
    filename = f"smart-canteen_{report}_{start.isoformat()}_{end.isoformat()}.csv"
    return Response(
        csv_text,
        mimetype="text/csv",
        headers={"Content-Disposition": f"attachment; filename={filename}"},
    )
