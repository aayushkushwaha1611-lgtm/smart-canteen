"""Admin inventory management: stock levels, thresholds, availability."""
from flask import abort, flash, redirect, render_template, request, url_for

from app import db
from app.forms.food_forms import StockUpdateForm
from app.models.food import FoodItem
from app.routes.admin import bp
from app.services.inventory_service import InventoryService


@bp.route("/inventory")
def inventory():
    page = max(1, request.args.get("page", 1, type=int))
    q = (request.args.get("q") or "").strip()
    only = (request.args.get("only") or "").strip()

    query = FoodItem.query.filter_by(is_active=True)
    if q:
        query = query.filter(FoodItem.name.ilike(f"%{q}%"))
    if only == "low":
        query = query.filter(FoodItem.stock_quantity <= FoodItem.low_stock_threshold)
    elif only == "out":
        query = query.filter(FoodItem.stock_quantity <= 0)

    pagination = query.order_by(FoodItem.stock_quantity.asc(), FoodItem.name).paginate(
        page=page, per_page=12, error_out=False
    )
    low_stock = InventoryService.low_stock_items()
    return render_template(
        "admin/inventory.html",
        pagination=pagination,
        low_stock=low_stock,
        q=q,
        only=only,
    )


@bp.route("/inventory/<int:food_id>/update", methods=["POST"])
def update_stock(food_id):
    food = db.session.get(FoodItem, food_id)
    if food is None:
        abort(404, description="Food item not found.")

    form = StockUpdateForm()
    if form.validate_on_submit():
        InventoryService.update_stock(
            food,
            form.stock_quantity.data,
            threshold=form.low_stock_threshold.data,
            is_available=form.is_available.data,
        )
        state = food.stock_status.replace("_", " ")
        flash(f"Stock updated for '{food.name}' — now {food.stock_quantity} ({state}).", "success")
    else:
        for field, errors in form.errors.items():
            flash(f"{field}: {'; '.join(errors)}", "danger")

    return redirect(request.referrer or url_for("admin.inventory"))
