"""Cart models - one active cart per user with line items."""
from datetime import datetime

from app import db


class Cart(db.Model):
    """Shopping cart belonging to a single student."""

    __tablename__ = "cart"

    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(
        db.Integer,
        db.ForeignKey("users.id", ondelete="CASCADE"),
        nullable=False,
        unique=True,
        index=True,
    )
    created_at = db.Column(db.DateTime, nullable=False, default=datetime.utcnow)
    updated_at = db.Column(
        db.DateTime, nullable=False, default=datetime.utcnow, onupdate=datetime.utcnow
    )

    user = db.relationship("User", back_populates="cart")
    items = db.relationship(
        "CartItem",
        back_populates="cart",
        cascade="all, delete-orphan",
        lazy="joined",
        order_by="CartItem.id",
    )

    @property
    def item_count(self) -> int:
        return sum(item.quantity for item in self.items)

    @property
    def subtotal(self) -> float:
        """Subtotal computed from current unit prices held on each food item."""
        return round(
            sum(float(item.food_item.price) * item.quantity for item in self.items if item.food_item),
            2,
        )

    def __repr__(self) -> str:  # pragma: no cover
        return f"<Cart user={self.user_id} items={len(self.items)}>"


class CartItem(db.Model):
    """A food item line inside a cart."""

    __tablename__ = "cart_items"
    __table_args__ = (
        db.UniqueConstraint("cart_id", "food_item_id", name="uq_cart_food"),
        db.CheckConstraint("quantity > 0", name="ck_cart_qty_positive"),
    )

    id = db.Column(db.Integer, primary_key=True)
    cart_id = db.Column(
        db.Integer, db.ForeignKey("cart.id", ondelete="CASCADE"), nullable=False, index=True
    )
    food_item_id = db.Column(
        db.Integer, db.ForeignKey("food_items.id", ondelete="CASCADE"), nullable=False, index=True
    )
    quantity = db.Column(db.Integer, nullable=False, default=1)
    added_at = db.Column(db.DateTime, nullable=False, default=datetime.utcnow)

    cart = db.relationship("Cart", back_populates="items")
    food_item = db.relationship("FoodItem", back_populates="cart_items")

    @property
    def line_total(self) -> float:
        return round(float(self.food_item.price) * self.quantity, 2) if self.food_item else 0.0

    def __repr__(self) -> str:  # pragma: no cover
        return f"<CartItem food={self.food_item_id} qty={self.quantity}>"
