"""Order models - orders, order lines and status history."""
from datetime import datetime

from app import db


class OrderStatus:
    """Order lifecycle states and their legal transitions."""

    ORDER_PLACED = "order_placed"
    CONFIRMED = "confirmed"
    PREPARING = "preparing"
    READY_FOR_PICKUP = "ready_for_pickup"
    COMPLETED = "completed"
    CANCELLED = "cancelled"

    ALL = (
        ORDER_PLACED,
        CONFIRMED,
        PREPARING,
        READY_FOR_PICKUP,
        COMPLETED,
        CANCELLED,
    )

    LABELS = {
        ORDER_PLACED: "Order Placed",
        CONFIRMED: "Confirmed",
        PREPARING: "Preparing",
        READY_FOR_PICKUP: "Ready for Pickup",
        COMPLETED: "Completed",
        CANCELLED: "Cancelled",
    }

    # Linear kitchen pipeline shown on the student tracker
    TRACKING_STEPS = (ORDER_PLACED, CONFIRMED, PREPARING, READY_FOR_PICKUP, COMPLETED)

    # Which statuses an action may move FROM -> TO
    TRANSITIONS = {
        ORDER_PLACED: frozenset({CONFIRMED, CANCELLED}),
        CONFIRMED: frozenset({PREPARING, CANCELLED}),
        PREPARING: frozenset({READY_FOR_PICKUP}),
        READY_FOR_PICKUP: frozenset({COMPLETED}),
        COMPLETED: frozenset(),
        CANCELLED: frozenset(),
    }

    # Actions exposed in the admin panel mapped to their target status
    ACTIONS = {
        "confirm": CONFIRMED,
        "prepare": PREPARING,
        "ready": READY_FOR_PICKUP,
        "complete": COMPLETED,
        "cancel": CANCELLED,
    }

    CANCELLABLE = frozenset({ORDER_PLACED, CONFIRMED})
    ACTIVE = frozenset({ORDER_PLACED, CONFIRMED, PREPARING, READY_FOR_PICKUP})
    PENDING_KITCHEN = frozenset({ORDER_PLACED, CONFIRMED})

    @classmethod
    def can_transition(cls, current: str, target: str) -> bool:
        return target in cls.TRANSITIONS.get(current, frozenset())

    @classmethod
    def label(cls, status: str) -> str:
        return cls.LABELS.get(status, status.replace("_", " ").title())


class Order(db.Model):
    """A placed order belonging to a student."""

    __tablename__ = "orders"
    __table_args__ = (
        db.Index("ix_orders_user_created", "user_id", "created_at"),
        db.Index("ix_orders_status_created", "status", "created_at"),
    )

    id = db.Column(db.Integer, primary_key=True)
    order_number = db.Column(db.String(30), unique=True, nullable=False, index=True)
    user_id = db.Column(
        db.Integer, db.ForeignKey("users.id", ondelete="RESTRICT"), nullable=False, index=True
    )
    status = db.Column(db.String(30), nullable=False, default=OrderStatus.ORDER_PLACED, index=True)
    total_amount = db.Column(db.Numeric(10, 2, asdecimal=False), nullable=False, default=0.0)
    notes = db.Column(db.String(500), nullable=True)
    estimated_minutes = db.Column(db.Integer, nullable=False, default=10)
    estimated_ready_at = db.Column(db.DateTime, nullable=True)
    created_at = db.Column(db.DateTime, nullable=False, default=datetime.utcnow, index=True)
    updated_at = db.Column(
        db.DateTime, nullable=False, default=datetime.utcnow, onupdate=datetime.utcnow
    )
    cancelled_at = db.Column(db.DateTime, nullable=True)
    cancel_reason = db.Column(db.String(255), nullable=True)

    user = db.relationship("User", back_populates="orders")
    items = db.relationship(
        "OrderItem",
        back_populates="order",
        cascade="all, delete-orphan",
        lazy="joined",
        order_by="OrderItem.id",
    )
    status_history = db.relationship(
        "OrderStatusHistory",
        back_populates="order",
        cascade="all, delete-orphan",
        lazy="dynamic",
        order_by="OrderStatusHistory.created_at.asc()",
    )
    token = db.relationship(
        "Token", back_populates="order", uselist=False, cascade="all, delete-orphan"
    )

    @property
    def status_label(self) -> str:
        return OrderStatus.label(self.status)

    @property
    def is_cancellable(self) -> bool:
        return self.status in OrderStatus.CANCELLABLE

    @property
    def is_active(self) -> bool:
        return self.status in OrderStatus.ACTIVE

    @property
    def item_count(self) -> int:
        return sum(item.quantity for item in self.items)

    @property
    def total_float(self) -> float:
        return float(self.total_amount)

    def status_at(self, status: str):
        """Return the history row for a given status, if reached."""
        return self.status_history.filter_by(status=status).first()

    def __repr__(self) -> str:  # pragma: no cover
        return f"<Order {self.order_number} {self.status}>"


class OrderItem(db.Model):
    """Immutable snapshot of one food line inside an order."""

    __tablename__ = "order_items"
    __table_args__ = (
        db.Index("ix_order_items_order", "order_id"),
        db.CheckConstraint("quantity > 0", name="ck_order_qty_positive"),
    )

    id = db.Column(db.Integer, primary_key=True)
    order_id = db.Column(
        db.Integer, db.ForeignKey("orders.id", ondelete="CASCADE"), nullable=False
    )
    food_item_id = db.Column(
        db.Integer, db.ForeignKey("food_items.id", ondelete="SET NULL"), nullable=True, index=True
    )
    food_name = db.Column(db.String(120), nullable=False)
    price = db.Column(db.Numeric(10, 2, asdecimal=False), nullable=False)
    quantity = db.Column(db.Integer, nullable=False)
    line_total = db.Column(db.Numeric(10, 2, asdecimal=False), nullable=False)

    order = db.relationship("Order", back_populates="items")
    food_item = db.relationship("FoodItem", back_populates="order_items")

    def __repr__(self) -> str:  # pragma: no cover
        return f"<OrderItem {self.food_name} x{self.quantity}>"


class OrderStatusHistory(db.Model):
    """Append-only audit trail of every status change on an order."""

    __tablename__ = "order_status_history"

    id = db.Column(db.Integer, primary_key=True)
    order_id = db.Column(
        db.Integer, db.ForeignKey("orders.id", ondelete="CASCADE"), nullable=False, index=True
    )
    status = db.Column(db.String(30), nullable=False, index=True)
    note = db.Column(db.String(255), nullable=True)
    changed_by = db.Column(
        db.Integer, db.ForeignKey("users.id", ondelete="SET NULL"), nullable=True
    )
    created_at = db.Column(db.DateTime, nullable=False, default=datetime.utcnow)

    order = db.relationship("Order", back_populates="status_history")
    changed_by_user = db.relationship("User")

    @property
    def status_label(self) -> str:
        return OrderStatus.label(self.status)

    def __repr__(self) -> str:  # pragma: no cover
        return f"<OrderStatusHistory order={self.order_id} {self.status}>"
