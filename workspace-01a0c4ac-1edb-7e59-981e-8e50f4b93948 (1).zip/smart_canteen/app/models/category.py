"""Category model - food categories (Breakfast, Snacks, ...)."""
from datetime import datetime

from app import db


class Category(db.Model):
    """A food category grouping menu items."""

    __tablename__ = "categories"

    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(60), unique=True, nullable=False, index=True)
    slug = db.Column(db.String(80), unique=True, nullable=False, index=True)
    description = db.Column(db.String(255), nullable=True)
    image = db.Column(db.String(255), nullable=True)
    sort_order = db.Column(db.Integer, nullable=False, default=0)
    is_active = db.Column(db.Boolean, nullable=False, default=True)
    created_at = db.Column(db.DateTime, nullable=False, default=datetime.utcnow)
    updated_at = db.Column(
        db.DateTime, nullable=False, default=datetime.utcnow, onupdate=datetime.utcnow
    )

    food_items = db.relationship("FoodItem", back_populates="category", lazy="dynamic")

    @property
    def active_items(self):
        return self.food_items.filter_by(is_active=True)

    def __repr__(self) -> str:  # pragma: no cover
        return f"<Category {self.name}>"
