"""Token model - unique daily pickup tokens (A001, A002, ...)."""
from datetime import datetime

from app import db


class Token(db.Model):
    """A daily pickup token connected to exactly one order."""

    __tablename__ = "tokens"
    __table_args__ = (
        db.UniqueConstraint("token_number", "token_date", name="uq_token_daily"),
        db.UniqueConstraint("order_id", name="uq_token_order"),
    )

    id = db.Column(db.Integer, primary_key=True)
    token_number = db.Column(db.String(10), nullable=False, index=True)
    prefix = db.Column(db.String(2), nullable=False, default="A")
    daily_serial = db.Column(db.Integer, nullable=False)
    token_date = db.Column(db.Date, nullable=False, index=True)
    order_id = db.Column(
        db.Integer, db.ForeignKey("orders.id", ondelete="CASCADE"), nullable=False
    )
    created_at = db.Column(db.DateTime, nullable=False, default=datetime.utcnow)

    order = db.relationship("Order", back_populates="token")

    @staticmethod
    def format_number(prefix: str, serial: int) -> str:
        return f"{prefix}{serial:03d}"

    def __repr__(self) -> str:  # pragma: no cover
        return f"<Token {self.token_number} order={self.order_id}>"
