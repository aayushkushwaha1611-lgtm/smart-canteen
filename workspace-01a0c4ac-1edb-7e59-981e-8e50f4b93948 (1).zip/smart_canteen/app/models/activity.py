"""ActivityLog model - audit trail of important user actions."""
from datetime import datetime

from app import db


class ActivityLog(db.Model):
    """Audit record for significant actions (orders, admin edits, logins...)."""

    __tablename__ = "activity_logs"

    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(
        db.Integer, db.ForeignKey("users.id", ondelete="SET NULL"), nullable=True, index=True
    )
    action = db.Column(db.String(60), nullable=False, index=True)
    entity_type = db.Column(db.String(40), nullable=True)
    entity_id = db.Column(db.Integer, nullable=True)
    detail = db.Column(db.String(500), nullable=True)
    ip_address = db.Column(db.String(45), nullable=True)
    created_at = db.Column(db.DateTime, nullable=False, default=datetime.utcnow, index=True)

    user = db.relationship("User", back_populates="activity_logs")

    def __repr__(self) -> str:  # pragma: no cover
        return f"<ActivityLog {self.action} user={self.user_id}>"
