"""Setting model - simple key/value application settings."""
from datetime import datetime

from app import db


class Setting(db.Model):
    """Runtime application setting editable from the admin panel."""

    __tablename__ = "settings"

    id = db.Column(db.Integer, primary_key=True)
    key = db.Column(db.String(60), unique=True, nullable=False, index=True)
    value = db.Column(db.Text, nullable=False)
    label = db.Column(db.String(120), nullable=True)
    updated_at = db.Column(
        db.DateTime, nullable=False, default=datetime.utcnow, onupdate=datetime.utcnow
    )

    def __repr__(self) -> str:  # pragma: no cover
        return f"<Setting {self.key}={self.value}>"
