"""FoodItem model - dishes sold in the canteen."""
from datetime import datetime

from app import db


class FoodItem(db.Model):
    """A dish on the canteen menu."""

    __tablename__ = "food_items"
    __table_args__ = (
        db.CheckConstraint("stock_quantity >= 0", name="ck_food_stock_non_negative"),
        db.CheckConstraint("price >= 0", name="ck_food_price_non_negative"),
        db.Index("ix_food_items_availability", "is_available", "is_active"),
    )

    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(120), nullable=False, index=True)
    slug = db.Column(db.String(140), unique=True, nullable=False, index=True)
    description = db.Column(db.Text, nullable=True)
    category_id = db.Column(
        db.Integer, db.ForeignKey("categories.id", ondelete="RESTRICT"), nullable=False, index=True
    )
    price = db.Column(db.Numeric(10, 2, asdecimal=False), nullable=False, default=0.0)
    image = db.Column(db.String(255), nullable=True)
    prep_time_minutes = db.Column(db.Integer, nullable=False, default=10)
    stock_quantity = db.Column(db.Integer, nullable=False, default=0)
    low_stock_threshold = db.Column(db.Integer, nullable=False, default=5)
    is_available = db.Column(db.Boolean, nullable=False, default=True)
    is_active = db.Column(db.Boolean, nullable=False, default=True)
    is_special = db.Column(db.Boolean, nullable=False, default=False)
    created_at = db.Column(db.DateTime, nullable=False, default=datetime.utcnow)
    updated_at = db.Column(
        db.DateTime, nullable=False, default=datetime.utcnow, onupdate=datetime.utcnow
    )

    category = db.relationship("Category", back_populates="food_items")
    cart_items = db.relationship("CartItem", back_populates="food_item", lazy="dynamic")
    order_items = db.relationship("OrderItem", back_populates="food_item", lazy="dynamic")

    EMOJI = {
        "breakfast": "🍛",
        "snacks": "🥟",
        "main-course": "🍲",
        "fast-food": "🍔",
        "beverages": "🥤",
        "desserts": "🍰",
    }

    @property
    def stock_status(self) -> str:
        """One of: out_of_stock, low_stock, in_stock."""
        if self.stock_quantity <= 0:
            return "out_of_stock"
        if self.stock_quantity <= self.low_stock_threshold:
            return "low_stock"
        return "in_stock"

    @property
    def can_order(self) -> bool:
        """True when the item can be added to a cart right now."""
        return (
            self.is_active
            and self.is_available
            and self.stock_quantity > 0
        )

    @property
    def display_image(self) -> str | None:
        """URL for the food photo, or None when no photo exists."""
        if self.image:
            return self.image
        return None

    @property
    def placeholder_emoji(self) -> str:
        if self.category is not None:
            return self.EMOJI.get(self.category.slug, "🍽️")
        return "🍽️"

    @property
    def price_float(self) -> float:
        return float(self.price)

    def __repr__(self) -> str:  # pragma: no cover
        return f"<FoodItem {self.name} ₹{self.price}>"
