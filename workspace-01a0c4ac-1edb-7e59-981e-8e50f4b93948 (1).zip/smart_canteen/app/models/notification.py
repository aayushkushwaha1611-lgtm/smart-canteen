"""Notification model - in-app alerts for students and admins."""
from datetime import datetime

from app import db


class NotificationType:
    """Well-known notification type constants."""

    ORDER_PLACED = "order_placed"
    ORDER_CONFIRMED = "order_confirmed"
    ORDER_PREPARING = "order_preparing"
    ORDER_READY = "order_ready"
    ORDER_COMPLETED = "order_completed"
    ORDER_CANCELLED = "order_cancelled"
    LOW_STOCK = "low_stock"
    ACCOUNT = "account"
    GENERAL = "general"

    ICONS = {
        ORDER_PLACED: "🧾",
        ORDER_CONFIRMED: "✅",
        ORDER_PREPARING: "👨‍🍳",
        ORDER_READY: "🔔",
        ORDER_COMPLETED: "🎉",
        ORDER_CANCELLED: "❌",
        LOW_STOCK: "⚠️",
        ACCOUNT: "👤",
        GENERAL: "📣",
    }

    @classmethod
    def icon(cls, type_: str) -> str:
        return cls.ICONS.get(type_, "📣")


class Notification(db.Model):
    """An in-app notification belonging to one user."""

    __tablename__ = "notifications"
    __table_args__ = (
        db.Index("ix_notifications_user_read", "user_id", "is_read"),
    )

    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(
        db.Integer, db.ForeignKey("users.id", ondelete="CASCADE"), nullable=False, index=True
    )
    title = db.Column(db.String(150), nullable=False, default="Notification")
    message = db.Column(db.String(500), nullable=False)
    type = db.Column(db.String(30), nullable=False, default="general", index=True)
    link = db.Column(db.String(255), nullable=True)
    is_read = db.Column(db.Boolean, nullable=False, default=False)
    created_at = db.Column(db.DateTime, nullable=False, default=datetime.utcnow, index=True)

    user = db.relationship("User", back_populates="notifications")

    @property
    def icon(self) -> str:
        return NotificationType.icon(self.type)

    def __repr__(self) -> str:  # pragma: no cover
        return f"<Notification {self.type} user={self.user_id}>"
