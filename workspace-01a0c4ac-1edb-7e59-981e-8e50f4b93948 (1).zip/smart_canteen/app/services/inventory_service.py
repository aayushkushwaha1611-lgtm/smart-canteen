"""Inventory service - stock levels, availability flags, low-stock alerts."""
from datetime import datetime

from app import db
from app.models.food import FoodItem
from app.utils.helpers import log_activity


class InventoryService:
    """Stock can never go negative; zero stock auto-disables the item."""

    # ------------------------------------------------------------------
    # Transactional helpers used by OrderService (NO commit here)
    # ------------------------------------------------------------------
    @staticmethod
    def deduct(food: FoodItem, quantity: int) -> bool:
        """Atomically deduct stock. Returns False when insufficient.

        Uses a conditional UPDATE so concurrent checkouts can never push the
        stock below zero (database CHECK constraint is the final backstop).
        """
        rows = (
            FoodItem.query.filter(
                FoodItem.id == food.id, FoodItem.stock_quantity >= quantity
            )
            .update(
                {FoodItem.stock_quantity: FoodItem.stock_quantity - quantity},
                synchronize_session=False,
            )
        )
        if not rows:
            return False
        food.stock_quantity = (food.stock_quantity or 0) - quantity
        if food.stock_quantity <= 0:
            food.stock_quantity = max(food.stock_quantity, 0)
            food.is_available = False
        elif food.stock_quantity <= food.low_stock_threshold:
            NotificationServiceLazy.low_stock(food)
        return True

    @staticmethod
    def restore(food: FoodItem, quantity: int) -> None:
        """Return stock after a cancellation (never below zero)."""
        quantity = max(int(quantity), 0)
        if quantity == 0:
            return
        FoodItem.query.filter(FoodItem.id == food.id).update(
            {FoodItem.stock_quantity: FoodItem.stock_quantity + quantity},
            synchronize_session=False,
        )
        food.stock_quantity = (food.stock_quantity or 0) + quantity
        # Restocked item becomes orderable again unless manually deactivated.
        if food.stock_quantity > 0 and food.is_active and not food.is_available:
            food.is_available = True

    # ------------------------------------------------------------------
    # Admin stock update (commits)
    # ------------------------------------------------------------------
    @staticmethod
    def update_stock(food: FoodItem, new_quantity: int, threshold: int | None = None,
                     is_available: bool | None = None, actor=None, commit: bool = True) -> None:
        """Absolute stock update from the inventory page. Never negative."""
        new_quantity = max(int(new_quantity), 0)
        old = food.stock_quantity
        food.stock_quantity = new_quantity
        if threshold is not None:
            food.low_stock_threshold = max(int(threshold), 0)
        if is_available is not None:
            food.is_available = bool(is_available) and new_quantity > 0
        elif new_quantity == 0:
            food.is_available = False
        elif old == 0 and new_quantity > 0 and food.is_active:
            food.is_available = True

        log_activity(
            "stock_update",
            "food_item",
            food.id,
            f"{food.name}: stock {old} → {new_quantity}",
        )
        if commit:
            db.session.commit()

        if food.stock_quantity <= food.low_stock_threshold:
            from app.services.notification_service import NotificationService

            NotificationService.low_stock_alert(food, commit=True)

    @staticmethod
    def low_stock_items():
        return (
            FoodItem.query.filter(
                FoodItem.is_active.is_(True),
                FoodItem.stock_quantity <= FoodItem.low_stock_threshold,
            )
            .order_by(FoodItem.stock_quantity.asc())
            .all()
        )

    @staticmethod
    def auto_disable(food: FoodItem) -> None:
        """Mark an item unavailable the moment it runs out of stock."""
        if food.stock_quantity <= 0:
            food.stock_quantity = 0
            food.is_available = False


class NotificationServiceLazy:
    """Import shim to avoid circular imports at module load."""

    @staticmethod
    def low_stock(food):
        from app.services.notification_service import NotificationService

        return NotificationService.low_stock_alert(food, commit=False)
