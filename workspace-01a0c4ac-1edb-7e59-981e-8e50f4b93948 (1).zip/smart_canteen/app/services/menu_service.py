"""Menu service - shared queries for the student menu and dashboards."""
from sqlalchemy import func

from app import db
from app.models.category import Category
from app.models.food import FoodItem
from app.models.order import Order, OrderItem, OrderStatus


class MenuService:
    """Read-side queries used by home, menu and dashboard pages."""

    @staticmethod
    def popular_items(limit: int = 6):
        """Best-selling available items (padded with newest stock if needed)."""
        rows = (
            db.session.query(OrderItem.food_item_id, func.sum(OrderItem.quantity).label("qty"))
            .join(Order, Order.id == OrderItem.order_id)
            .filter(Order.status != OrderStatus.CANCELLED, OrderItem.food_item_id.isnot(None))
            .group_by(OrderItem.food_item_id)
            .order_by(func.sum(OrderItem.quantity).desc())
            .limit(limit * 3)
            .all()
        )
        items = []
        for food_id, _qty in rows:
            food = db.session.get(FoodItem, food_id)
            if food and food.is_active and food not in items:
                items.append(food)
            if len(items) >= limit:
                break
        if len(items) < limit:
            extras = (
                FoodItem.query.filter_by(is_active=True)
                .order_by(FoodItem.created_at.desc())
                .limit(limit * 2)
                .all()
            )
            for food in extras:
                if food not in items:
                    items.append(food)
                if len(items) >= limit:
                    break
        return items[:limit]

    @staticmethod
    def todays_specials(limit: int = 6):
        return (
            FoodItem.query.filter_by(is_active=True, is_special=True)
            .order_by(FoodItem.name)
            .limit(limit)
            .all()
        )

    @staticmethod
    def todays_menu(limit: int | None = None):
        query = FoodItem.query.filter_by(is_active=True, is_available=True).order_by(
            FoodItem.category_id, FoodItem.name
        )
        return query.limit(limit).all() if limit else query.all()

    @staticmethod
    def menu_query(q=None, category_slug=None, min_price=None, max_price=None, sort="popular"):
        """Build the filtered/sorted menu query (all filtering server-side)."""
        query = FoodItem.query.filter_by(is_active=True)

        if category_slug:
            query = query.join(Category).filter(Category.slug == category_slug)
        if q:
            like = f"%{q.strip()}%"
            query = query.filter(
                db.or_(FoodItem.name.ilike(like), FoodItem.description.ilike(like))
            )
        if min_price is not None:
            query = query.filter(FoodItem.price >= float(min_price))
        if max_price is not None:
            query = query.filter(FoodItem.price <= float(max_price))

        if sort == "price_asc":
            query = query.order_by(FoodItem.price.asc(), FoodItem.name.asc())
        elif sort == "price_desc":
            query = query.order_by(FoodItem.price.desc(), FoodItem.name.asc())
        elif sort == "name":
            query = query.order_by(FoodItem.name.asc())
        elif sort == "newest":
            query = query.order_by(FoodItem.created_at.desc())
        else:  # popular (default)
            popularity = (
                db.session.query(
                    OrderItem.food_item_id.label("fid"),
                    func.coalesce(func.sum(OrderItem.quantity), 0).label("sold"),
                )
                .join(Order, Order.id == OrderItem.order_id)
                .filter(Order.status != OrderStatus.CANCELLED)
                .group_by(OrderItem.food_item_id)
                .subquery()
            )
            query = (
                query.outerjoin(popularity, popularity.c.fid == FoodItem.id)
                .order_by(func.coalesce(popularity.c.sold, 0).desc(), FoodItem.name.asc())
            )
        return query

    @staticmethod
    def active_categories():
        return Category.query.filter_by(is_active=True).order_by(Category.sort_order, Category.name).all()

    @staticmethod
    def category_counts():
        rows = (
            db.session.query(Category.id, func.count(FoodItem.id))
            .outerjoin(FoodItem, (FoodItem.category_id == Category.id) & (FoodItem.is_active.is_(True)))
            .filter(Category.is_active.is_(True))
            .group_by(Category.id)
            .all()
        )
        return dict(rows)
