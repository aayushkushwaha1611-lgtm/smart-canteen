"""Token service - unique daily pickup tokens (A001, A002, ...)."""
from app import db
from app.models.token import Token
from app.utils.helpers import today_ist_date


class TokenService:
    """Generates daily sequential tokens bound 1:1 to orders."""

    PREFIX = "A"

    @staticmethod
    def generate(order, token_date=None) -> Token:
        """Create the next token of the current IST business day.

        Must run inside the placing order's transaction so the token and the
        order commit (or roll back) together. The unique constraint on
        (token_number, token_date) protects against duplicates. `token_date`
        may be supplied for back-dated (seeded) orders.
        """
        if token_date is None:
            token_date = today_ist_date()
        last = (
            Token.query.filter_by(token_date=token_date)
            .order_by(Token.daily_serial.desc())
            .first()
        )
        serial = (last.daily_serial + 1) if last else 1
        token = Token(
            token_number=Token.format_number(TokenService.PREFIX, serial),
            prefix=TokenService.PREFIX,
            daily_serial=serial,
            token_date=token_date,
            order_id=order.id,
        )
        db.session.add(token)
        db.session.flush()
        return token

    @staticmethod
    def for_order(order) -> Token | None:
        return Token.query.filter_by(order_id=order.id).first()
