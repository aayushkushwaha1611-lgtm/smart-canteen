"""Settings service - key/value application settings with sane defaults."""
from app import db
from app.models.setting import Setting

DEFAULTS = {
    "canteen_name": ("Smart Canteen", "Canteen Name"),
    "pickup_location": ("Main Canteen Counter — Ground Floor", "Pickup Location"),
    "pickup_message": (
        "Show your digital token at the counter. Please collect within 10 minutes of the order becoming ready.",
        "Pickup Message",
    ),
    "cancel_window_minutes": ("10", "Student cancellation window (minutes)"),
    "low_stock_default": ("5", "Default low-stock threshold"),
}


class SettingsService:
    """Read/update application settings from the admin panel."""

    @staticmethod
    def all() -> dict:
        """Merged view: defaults overlaid with stored values."""
        merged = {key: meta[0] for key, meta in DEFAULTS.items()}
        for setting in Setting.query.all():
            merged[setting.key] = setting.value
        return merged

    @staticmethod
    def get(key: str, default: str | None = None) -> str:
        if default is None:
            default = DEFAULTS.get(key, ("",))[0]
        setting = Setting.query.filter_by(key=key).first()
        return setting.value if setting else default

    @staticmethod
    def get_int(key: str, default: int) -> int:
        try:
            return int(SettingsService.get(key, str(default)))
        except (TypeError, ValueError):
            return default

    @staticmethod
    def set(key: str, value: str, commit: bool = True) -> None:
        setting = Setting.query.filter_by(key=key).first()
        if setting is None:
            setting = Setting(key=key, value=str(value), label=DEFAULTS.get(key, (None, None))[1])
            db.session.add(setting)
        else:
            setting.value = str(value)
        if commit:
            db.session.commit()

    @staticmethod
    def update_from_form(form, commit: bool = True) -> None:
        SettingsService.set("canteen_name", form.canteen_name.data.strip(), commit=False)
        SettingsService.set("pickup_location", form.pickup_location.data.strip(), commit=False)
        SettingsService.set(
            "pickup_message", (form.pickup_message.data or "").strip(), commit=False
        )
        SettingsService.set(
            "cancel_window_minutes", str(form.cancel_window_minutes.data), commit=False
        )
        SettingsService.set("low_stock_default", str(form.low_stock_default.data), commit=False)
        if commit:
            db.session.commit()
