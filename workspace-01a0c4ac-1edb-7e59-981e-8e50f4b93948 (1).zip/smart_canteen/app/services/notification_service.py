"""Notification service - in-app notifications for students and admins."""
from datetime import datetime

from app import db
from app.models.notification import Notification, NotificationType
from app.models.order import OrderStatus
from app.models.user import User


class NotificationService:
    """Creates and manages notifications.

    `send` only adds to the current transaction (so it can participate in an
    order transaction); pass commit=True when called standalone.
    """

    @staticmethod
    def send(user, title: str, message: str, type_: str = "general",
             link: str | None = None, commit: bool = False) -> Notification:
        notification = Notification(
            user_id=user.id if hasattr(user, "id") else int(user),
            title=title,
            message=message,
            type=type_,
            link=link,
        )
        db.session.add(notification)
        if commit:
            db.session.commit()
        return notification

    @staticmethod
    def notify_admins(title: str, message: str, type_: str = "general",
                      link: str | None = None, exclude_user=None, commit: bool = False):
        admins = User.query.filter_by(role="admin", is_active=True).all()
        created = []
        for admin in admins:
            if exclude_user is not None and admin.id == exclude_user.id:
                continue
            created.append(
                NotificationService.send(admin, title, message, type_, link, commit=False)
            )
        if commit:
            db.session.commit()
        return created

    # ------------------------------------------------------------------
    # Order lifecycle notifications
    # ------------------------------------------------------------------
    @staticmethod
    def notify_new_order(order, commit: bool = False):
        token_no = order.token.token_number if order.token else "—"
        NotificationService.send(
            order.user,
            "Order placed 🧾",
            f"Order {order.order_number} was placed successfully. Your token is {token_no}.",
            NotificationType.ORDER_PLACED,
            link=f"/orders/{order.id}",
            commit=commit,
        )
        NotificationService.notify_admins(
            "New order received 🆕",
            f"{order.user.full_name} placed {order.order_number} "
            f"(token {token_no}) — total ₹{float(order.total_amount):.2f}.",
            NotificationType.ORDER_PLACED,
            link=f"/admin/orders/{order.id}",
            commit=commit,
        )

    @staticmethod
    def notify_status_change(order, status: str, commit: bool = False):
        cfg = {
            OrderStatus.CONFIRMED: ("Order confirmed ✅", "Your order {no} has been confirmed and will start cooking shortly.", NotificationType.ORDER_CONFIRMED),
            OrderStatus.PREPARING: ("Order preparing 👨‍🍳", "Great! The kitchen is preparing your order {no}.", NotificationType.ORDER_PREPARING),
            OrderStatus.READY_FOR_PICKUP: ("Order ready 🔔", "Order {no} is ready for pickup. Token {tk} — please collect it now!", NotificationType.ORDER_READY),
            OrderStatus.COMPLETED: ("Order completed 🎉", "Order {no} has been completed. Enjoy your meal, see you next time!", NotificationType.ORDER_COMPLETED),
            OrderStatus.CANCELLED: ("Order cancelled ❌", "Order {no} has been cancelled. Any paid stock has been restored.", NotificationType.ORDER_CANCELLED),
        }
        if status not in cfg:
            return
        title, template, type_ = cfg[status]
        token_no = order.token.token_number if order.token else "—"
        NotificationService.send(
            order.user,
            title,
            template.format(no=order.order_number, tk=token_no),
            type_,
            link=f"/orders/{order.id}",
            commit=commit,
        )
        if status == OrderStatus.CANCELLED:
            NotificationService.notify_admins(
                "Order cancelled",
                f"{order.order_number} ({order.user.full_name}) was cancelled.",
                NotificationType.ORDER_CANCELLED,
                link=f"/admin/orders/{order.id}",
                commit=commit,
            )

    @staticmethod
    def low_stock_alert(food, commit: bool = False):
        """Alert admins once (unread duplicate suppression) when stock is low."""
        existing = (
            Notification.query.filter(
                Notification.type == NotificationType.LOW_STOCK,
                Notification.is_read.is_(False),
                Notification.message.ilike(f"%{food.name}%"),
            ).first()
        )
        if existing:
            return None
        if food.stock_quantity <= 0:
            msg = f"'{food.name}' is OUT OF STOCK and was auto-disabled. Restock to re-enable."
        else:
            msg = (
                f"'{food.name}' is running low: only {food.stock_quantity} left "
                f"(threshold {food.low_stock_threshold})."
            )
        return NotificationService.notify_admins(
            "Low-stock alert ⚠️",
            msg,
            NotificationType.LOW_STOCK,
            link="/admin/inventory",
            commit=commit,
        )

    # ------------------------------------------------------------------
    @staticmethod
    def mark_read(notification, commit: bool = True) -> None:
        notification.is_read = True
        if commit:
            db.session.commit()

    @staticmethod
    def mark_all_read(user, commit: bool = True) -> int:
        count = (
            Notification.query.filter_by(user_id=user.id, is_read=False)
            .update({"is_read": True}, synchronize_session=False)
        )
        if commit:
            db.session.commit()
        return count

    @staticmethod
    def unread_count(user) -> int:
        return Notification.query.filter_by(user_id=user.id, is_read=False).count()
