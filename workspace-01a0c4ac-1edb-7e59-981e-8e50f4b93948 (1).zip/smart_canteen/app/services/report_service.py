"""Report service - analytics for the admin reports page and CSV export.

Timestamps are stored in UTC; business days are IST calendar days. Series
builders bucket in Python so day boundaries are always IST-correct.
"""
from datetime import date, datetime, time, timedelta
from zoneinfo import ZoneInfo

from sqlalchemy import func

from app import db
from app.models.category import Category
from app.models.food import FoodItem
from app.models.order import Order, OrderItem, OrderStatus
from app.models.user import User

IST = ZoneInfo("Asia/Kolkata")
UTC = ZoneInfo("UTC")


def _to_utc(d: date) -> datetime:
    """Start of an IST calendar day expressed as naive UTC (DB storage)."""
    aware = datetime.combine(d, time.min, tzinfo=IST)
    return aware.astimezone(UTC).replace(tzinfo=None)


def _day_range(start: date, end: date) -> tuple[datetime, datetime]:
    """Inclusive [start..end] IST days as a naive-UTC half-open range."""
    return _to_utc(start), _to_utc(end + timedelta(days=1))


def _ist_date(dt: datetime | None) -> date | None:
    if dt is None:
        return None
    if dt.tzinfo is None:
        dt = dt.replace(tzinfo=UTC)
    return dt.astimezone(IST).date()


class ReportService:
    """Aggregations over orders (volume/revenue) with date filtering."""

    # ------------------------------------------------------------------
    @staticmethod
    def _base_orders(start: date | None, end: date | None, statuses=None):
        query = Order.query
        if start and end:
            lo, hi = _day_range(start, end)
            query = query.filter(Order.created_at >= lo, Order.created_at < hi)
        if statuses:
            query = query.filter(Order.status.in_(statuses))
        return query

    @staticmethod
    def daily_series(start: date, end: date):
        """[(iso_date, orders, revenue)] for every IST day in the range."""
        lo, hi = _day_range(start, end)
        rows = (
            db.session.query(Order.created_at, Order.total_amount)
            .filter(Order.created_at >= lo, Order.created_at < hi, Order.status != OrderStatus.CANCELLED)
            .all()
        )
        by_day: dict[date, list] = {}
        for created, total in rows:
            day = _ist_date(created)
            if day is None:
                continue
            bucket = by_day.setdefault(day, [0, 0.0])
            bucket[0] += 1
            bucket[1] += float(total)

        series = []
        d = start
        while d <= end:
            orders, revenue = by_day.get(d, [0, 0.0])
            series.append((d.isoformat(), orders, round(revenue, 2)))
            d += timedelta(days=1)
        return series

    @staticmethod
    def weekly_series(start: date, end: date):
        """[(iso_year-Www, orders, revenue)] grouped by ISO week."""
        lo, hi = _day_range(start, end)
        rows = (
            db.session.query(Order.created_at, Order.total_amount)
            .filter(Order.created_at >= lo, Order.created_at < hi, Order.status != OrderStatus.CANCELLED)
            .all()
        )
        per_week: dict[str, list] = {}
        for created, total in rows:
            day = _ist_date(created)
            if day is None:
                continue
            iso = day.isocalendar()
            key = f"{iso[0]}-W{iso[1]:02d}"
            bucket = per_week.setdefault(key, [0, 0.0])
            bucket[0] += 1
            bucket[1] += float(total)
        return [(k, v[0], round(v[1], 2)) for k, v in sorted(per_week.items())]

    @staticmethod
    def monthly_series(start: date, end: date):
        """[(YYYY-MM, orders, revenue)] grouped by IST month."""
        lo, hi = _day_range(start, end)
        rows = (
            db.session.query(Order.created_at, Order.total_amount)
            .filter(Order.created_at >= lo, Order.created_at < hi, Order.status != OrderStatus.CANCELLED)
            .all()
        )
        per_month: dict[str, list] = {}
        for created, total in rows:
            day = _ist_date(created)
            if day is None:
                continue
            key = f"{day.year:04d}-{day.month:02d}"
            bucket = per_month.setdefault(key, [0, 0.0])
            bucket[0] += 1
            bucket[1] += float(total)
        return [(k, v[0], round(v[1], 2)) for k, v in sorted(per_month.items())]

    @staticmethod
    def popular_items(limit: int = 8, start: date | None = None, end: date | None = None):
        query = (
            db.session.query(
                OrderItem.food_name,
                func.sum(OrderItem.quantity).label("qty"),
                func.sum(OrderItem.line_total).label("revenue"),
            )
            .join(Order, Order.id == OrderItem.order_id)
            .filter(Order.status != OrderStatus.CANCELLED)
        )
        if start and end:
            lo, hi = _day_range(start, end)
            query = query.filter(Order.created_at >= lo, Order.created_at < hi)
        return [
            (str(name), int(qty or 0), round(float(rev or 0), 2))
            for name, qty, rev in (
                query.group_by(OrderItem.food_name)
                .order_by(func.sum(OrderItem.quantity).desc())
                .limit(limit)
                .all()
            )
        ]

    @staticmethod
    def category_performance(start: date | None = None, end: date | None = None):
        query = (
            db.session.query(
                Category.name,
                func.count(OrderItem.id).label("lines"),
                func.coalesce(func.sum(OrderItem.quantity), 0).label("qty"),
                func.coalesce(func.sum(OrderItem.line_total), 0.0).label("revenue"),
            )
            .select_from(OrderItem)
            .join(FoodItem, FoodItem.id == OrderItem.food_item_id)
            .join(Category, Category.id == FoodItem.category_id)
            .join(Order, Order.id == OrderItem.order_id)
            .filter(Order.status != OrderStatus.CANCELLED)
        )
        if start and end:
            lo, hi = _day_range(start, end)
            query = query.filter(Order.created_at >= lo, Order.created_at < hi)
        return [
            (str(name), int(lines or 0), int(qty or 0), round(float(rev or 0), 2))
            for name, lines, qty, rev in (
                query.group_by(Category.name)
                .order_by(func.sum(OrderItem.line_total).desc())
                .all()
            )
        ]

    @staticmethod
    def status_summary(start: date | None = None, end: date | None = None) -> dict:
        query = db.session.query(Order.status, func.count(Order.id)).group_by(Order.status)
        if start and end:
            lo, hi = _day_range(start, end)
            query = query.filter(Order.created_at >= lo, Order.created_at < hi)
        counts = {status: 0 for status in OrderStatus.ALL}
        for status, count in query.all():
            counts[status] = int(count)
        return counts

    @staticmethod
    def revenue_totals(start: date | None = None, end: date | None = None):
        query = db.session.query(func.coalesce(func.sum(Order.total_amount), 0.0)).filter(
            Order.status != OrderStatus.CANCELLED
        )
        if start and end:
            lo, hi = _day_range(start, end)
            query = query.filter(Order.created_at >= lo, Order.created_at < hi)
        return round(float(query.scalar() or 0.0), 2)

    # ------------------------------------------------------------------
    # Dashboard stats
    # ------------------------------------------------------------------
    @staticmethod
    def dashboard_stats() -> dict:
        from app.services.inventory_service import InventoryService

        today = datetime.now(IST).date()
        week_ago = today - timedelta(days=6)
        month_ago = today - timedelta(days=29)
        counts = ReportService.status_summary()

        return {
            "total_students": User.query.filter_by(role="student").count(),
            "total_orders": Order.query.count(),
            "status_counts": counts,
            "pending_orders": counts.get(OrderStatus.ORDER_PLACED, 0),
            "preparing_orders": counts.get(OrderStatus.PREPARING, 0),
            "ready_orders": counts.get(OrderStatus.READY_FOR_PICKUP, 0),
            "completed_orders": counts.get(OrderStatus.COMPLETED, 0),
            "cancelled_orders": counts.get(OrderStatus.CANCELLED, 0),
            "today_revenue": ReportService.revenue_totals(today, today),
            "total_revenue": ReportService.revenue_totals(),
            "revenue_7d": ReportService.daily_series(week_ago, today),
            "popular_items": ReportService.popular_items(5),
            "low_stock_items": InventoryService.low_stock_items(),
        }

    # ------------------------------------------------------------------
    # CSV export
    # ------------------------------------------------------------------
    @staticmethod
    def csv_report(report: str, start: date, end: date) -> str:
        """Render a report as CSV text (UTF-8, comma separated)."""
        import csv
        import io

        buf = io.StringIO()
        writer = csv.writer(buf)

        if report == "daily_orders":
            writer.writerow(["Date (IST)", "Orders", "Revenue (INR)"])
            for d, c, r in ReportService.daily_series(start, end):
                writer.writerow([d, c, f"{r:.2f}"])
        elif report == "weekly_orders":
            writer.writerow(["Week (ISO)", "Orders", "Revenue (INR)"])
            for w, c, r in ReportService.weekly_series(start, end):
                writer.writerow([w, c, f"{r:.2f}"])
        elif report == "monthly_orders":
            writer.writerow(["Month", "Orders", "Revenue (INR)"])
            for m, c, r in ReportService.monthly_series(start, end):
                writer.writerow([m, c, f"{r:.2f}"])
        elif report == "popular_items":
            writer.writerow(["Food Item", "Quantity Sold", "Revenue (INR)"])
            for name, qty, rev in ReportService.popular_items(50, start, end):
                writer.writerow([name, int(qty or 0), f"{float(rev or 0):.2f}"])
        elif report == "category_performance":
            writer.writerow(["Category", "Order Lines", "Quantity", "Revenue (INR)"])
            for name, lines, qty, rev in ReportService.category_performance(start, end):
                writer.writerow([name, int(lines or 0), int(qty or 0), f"{float(rev or 0):.2f}"])
        elif report == "order_statuses":
            writer.writerow(["Status", "Orders"])
            for status, count in ReportService.status_summary(start, end).items():
                writer.writerow([OrderStatus.label(status), count])
        elif report == "orders":
            from app.utils.helpers import format_dt

            writer.writerow(
                ["Order Number", "Token", "Student", "Items", "Total (INR)", "Status", "Placed At (IST)"]
            )
            for o in ReportService._base_orders(start, end).order_by(Order.created_at).all():
                writer.writerow(
                    [
                        o.order_number,
                        o.token.token_number if o.token else "",
                        o.user.full_name if o.user else "",
                        o.item_count,
                        f"{o.total_float:.2f}",
                        o.status_label,
                        format_dt(o.created_at),
                    ]
                )
        else:
            writer.writerow(["Unknown report", report])

        return buf.getvalue()
