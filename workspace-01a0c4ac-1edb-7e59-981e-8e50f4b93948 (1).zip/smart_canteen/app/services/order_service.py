"""Order service - checkout, tokens, status workflow and cancellation."""
from datetime import datetime, timedelta

from app import db
from app.models.food import FoodItem
from app.models.order import Order, OrderItem, OrderStatus, OrderStatusHistory
from app.models.user import User
from app.services.cart_service import CartService, MAX_QTY_PER_ITEM
from app.services.inventory_service import InventoryService
from app.services.notification_service import NotificationService
from app.services.settings_service import SettingsService
from app.services.token_service import TokenService
from app.utils.helpers import log_activity


class OrderError(Exception):
    """Raised whenever an order operation fails business validation."""


class OrderService:
    """Checkout pipeline and the order status state-machine.

    place_order() performs the 13-step checkout inside a single database
    transaction - it either commits completely or rolls back completely.
    """

    # ------------------------------------------------------------------
    # Checkout
    # ------------------------------------------------------------------
    @staticmethod
    def place_order(user: User, notes: str | None = None) -> Order:
        # 1. Validate user
        if user is None or not user.is_authenticated:
            raise OrderError("Please log in to place an order.")
        if not user.is_active:
            raise OrderError("Your account is deactivated. Contact the canteen administrator.")

        # 2. Validate cart (returns snapshot lines of (food, qty))
        ok, message, lines = CartService.validate(user)
        if not ok:
            raise OrderError(message)

        # 3-5. Validate availability, stock and prices (server-side only)
        total = 0.0
        est_minutes = 0
        priced_lines = []
        for food, qty in lines:
            if not food.is_active or not food.is_available:
                raise OrderError(f"'{food.name}' is not available right now.")
            if qty > food.stock_quantity:
                raise OrderError(f"Not enough stock for '{food.name}'.")
            if qty > MAX_QTY_PER_ITEM:
                raise OrderError(f"Quantity for '{food.name}' exceeds the limit.")
            price = round(float(food.price), 2)  # authoritative DB price
            if price <= 0:
                raise OrderError(f"Invalid price for '{food.name}'. Please contact the canteen.")
            priced_lines.append((food, qty, price))
            total += price * qty
            est_minutes = max(est_minutes, int(food.prep_time_minutes or 10))

        # 6. Calculate total on the server
        total = round(total, 2)

        # Kitchen load adds a small buffer when many orders are pending
        active_orders = Order.query.filter(Order.status.in_(OrderStatus.ACTIVE)).count()
        est_minutes += min(active_orders * 2, 15)

        try:
            # 7. Create order (unique placeholder number replaced after flush)
            import uuid

            order = Order(
                order_number=f"ORD-TMP-{uuid.uuid4().hex[:12]}",
                user_id=user.id,
                status=OrderStatus.ORDER_PLACED,
                total_amount=total,
                notes=(notes or "").strip() or None,
                estimated_minutes=est_minutes,
                estimated_ready_at=datetime.utcnow() + timedelta(minutes=est_minutes),
            )
            db.session.add(order)
            db.session.flush()
            order.order_number = f"ORD-{datetime.utcnow():%Y%m%d}-{order.id:04d}"

            # 8. Create order items (price/name snapshots)
            for food, qty, price in priced_lines:
                db.session.add(
                    OrderItem(
                        order_id=order.id,
                        food_item_id=food.id,
                        food_name=food.name,
                        price=price,
                        quantity=qty,
                        line_total=round(price * qty, 2),
                    )
                )

            # 9. Reduce stock atomically (never negative) + auto-disable at zero
            for food, qty, _price in priced_lines:
                if not InventoryService.deduct(food, qty):
                    raise OrderError(f"'{food.name}' sold out while placing your order.")

            # 10. Generate unique daily token
            token = TokenService.generate(order)

            # Status history (initial state)
            db.session.add(
                OrderStatusHistory(
                    order_id=order.id, status=OrderStatus.ORDER_PLACED, changed_by=user.id
                )
            )

            # 11. Clear cart
            CartService.clear_items(CartService.get_or_create(user))

            # 12. Notifications (student + admins) and audit log
            NotificationService.notify_new_order(order)
            log_activity(
                "order_placed",
                "order",
                order.id,
                f"{order.order_number} token {token.token_number} total ₹{total:.2f}",
            )

            # 13. Commit everything atomically
            db.session.commit()
        except OrderError:
            db.session.rollback()
            raise
        except Exception as exc:  # pragma: no cover - defensive rollback
            db.session.rollback()
            raise OrderError("Could not place the order. Please try again.") from exc

        return order

    # ------------------------------------------------------------------
    # Status workflow
    # ------------------------------------------------------------------
    @staticmethod
    def change_status(order: Order, action_or_status: str, actor: User,
                      note: str | None = None, commit: bool = True) -> Order:
        """Advance the order state machine (admin kitchen actions).

        `action_or_status` is either a status string or an admin action key
        ('confirm', 'prepare', 'ready', 'complete', 'cancel').
        """
        target = OrderStatus.ACTIONS.get(action_or_status, action_or_status)
        if target == OrderStatus.CANCELLED:
            return OrderService.cancel_order(
                order, actor, is_admin=actor.is_admin, reason=note, commit=commit
            )

        if target not in OrderStatus.ALL:
            raise OrderError("Unknown order action.")
        if not OrderStatus.can_transition(order.status, target):
            raise OrderError(
                f"Cannot change '{order.order_number}' from "
                f"{OrderStatus.label(order.status)} to {OrderStatus.label(target)}."
            )

        order.status = target
        db.session.add(
            OrderStatusHistory(
                order_id=order.id, status=target, note=note, changed_by=actor.id
            )
        )
        NotificationService.notify_status_change(order, target)
        log_activity("order_status", "order", order.id,
                     f"{order.order_number} → {OrderStatus.label(target)}")
        if commit:
            db.session.commit()
        return order

    # ------------------------------------------------------------------
    # Cancellation
    # ------------------------------------------------------------------
    @staticmethod
    def can_student_cancel(order: Order) -> tuple[bool, str]:
        """Students may cancel their own order inside the cancel window."""
        if not order.is_cancellable:
            return False, "This order can no longer be cancelled."
        window = SettingsService.get_int("cancel_window_minutes", 10)
        if datetime.utcnow() - order.created_at > timedelta(minutes=window):
            return False, f"Cancellation window ({window} minutes) has passed."
        return True, "OK"

    @staticmethod
    def cancel_order(order: Order, actor: User, is_admin: bool = False,
                     reason: str | None = None, commit: bool = True) -> Order:
        if not OrderStatus.can_transition(order.status, OrderStatus.CANCELLED):
            raise OrderError(
                f"Order {order.order_number} is {OrderStatus.label(order.status)} and "
                "can no longer be cancelled."
            )

        # Stock is restored so nothing is lost on a cancellation
        for item in order.items:
            if item.food_item is not None:
                InventoryService.restore(item.food_item, item.quantity)

        order.status = OrderStatus.CANCELLED
        order.cancelled_at = datetime.utcnow()
        order.cancel_reason = (reason or "").strip()[:250] or None
        db.session.add(
            OrderStatusHistory(
                order_id=order.id,
                status=OrderStatus.CANCELLED,
                note=order.cancel_reason,
                changed_by=actor.id,
            )
        )
        NotificationService.notify_status_change(order, OrderStatus.CANCELLED)
        who = "admin" if is_admin else "student"
        log_activity("order_cancelled", "order", order.id,
                     f"{order.order_number} cancelled by {who}")
        if commit:
            db.session.commit()
        return order

    # ------------------------------------------------------------------
    # Queries
    # ------------------------------------------------------------------
    @staticmethod
    def current_order(user: User) -> Order | None:
        """Most recent still-active order for the student dashboard."""
        return (
            Order.query.filter(
                Order.user_id == user.id, Order.status.in_(OrderStatus.ACTIVE)
            )
            .order_by(Order.created_at.desc())
            .first()
        )

    @staticmethod
    def recently_ordered_items(user: User, limit: int = 4):
        """Distinct food items the student ordered before (most recent first)."""
        from sqlalchemy import func

        rows = (
            db.session.query(
                OrderItem.food_item_id,
                func.max(Order.created_at).label("last_ordered"),
            )
            .join(Order, Order.id == OrderItem.order_id)
            .filter(
                Order.user_id == user.id,
                Order.status != OrderStatus.CANCELLED,
                OrderItem.food_item_id.isnot(None),
            )
            .group_by(OrderItem.food_item_id)
            .order_by(func.max(Order.created_at).desc())
            .limit(limit)
            .all()
        )
        items = []
        for food_id, _last in rows:
            food = db.session.get(FoodItem, food_id)
            if food and food.is_active:
                items.append(food)
        return items
