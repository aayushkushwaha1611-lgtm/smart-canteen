"""Cart service - server-side cart operations with full validation."""
from datetime import datetime

from app import db
from app.models.cart import Cart, CartItem
from app.models.food import FoodItem
from app.models.user import User
from app.utils.validators import clamp_qty

MAX_QTY_PER_ITEM = 20


class CartService:
    """All cart mutations validate stock/availability server-side."""

    # ------------------------------------------------------------------
    @staticmethod
    def get_or_create(user) -> Cart:
        cart = Cart.query.filter_by(user_id=user.id).first()
        if cart is None:
            cart = Cart(user_id=user.id)
            db.session.add(cart)
            db.session.commit()
        return cart

    @staticmethod
    def item_count(user) -> int:
        """Total quantity of all lines in the user's cart (single query)."""
        from sqlalchemy import func

        total = (
            db.session.query(func.coalesce(func.sum(CartItem.quantity), 0))
            .join(Cart, Cart.id == CartItem.cart_id)
            .filter(Cart.user_id == user.id)
            .scalar()
        )
        return int(total or 0)

    @staticmethod
    def find_item(user, item_id: int) -> CartItem | None:
        cart = Cart.query.filter_by(user_id=user.id).first()
        if cart is None:
            return None
        return next((i for i in cart.items if i.id == item_id), None)

    # ------------------------------------------------------------------
    @staticmethod
    def add(user, food_id: int, quantity: int = 1) -> tuple[bool, str]:
        """Add a food item to the cart (merges quantities for repeats)."""
        food = db.session.get(FoodItem, food_id)
        if food is None or not food.is_active:
            return False, "This item is no longer available."
        if not food.is_available or food.stock_quantity <= 0:
            return False, f"'{food.name}' is currently out of stock."

        quantity = clamp_qty(quantity, 1, MAX_QTY_PER_ITEM)
        cart = CartService.get_or_create(user)
        line = next((i for i in cart.items if i.food_item_id == food.id), None)

        if line:
            new_qty = line.quantity + quantity
            if new_qty > MAX_QTY_PER_ITEM:
                return False, f"You can order at most {MAX_QTY_PER_ITEM} of '{food.name}'."
            if new_qty > food.stock_quantity:
                return False, f"Only {food.stock_quantity} x '{food.name}' left in stock."
            line.quantity = new_qty
        else:
            if quantity > food.stock_quantity:
                return False, f"Only {food.stock_quantity} x '{food.name}' left in stock."
            line = CartItem(cart_id=cart.id, food_item_id=food.id, quantity=quantity)
            db.session.add(line)

        cart.updated_at = datetime.utcnow()
        db.session.commit()
        return True, f"'{food.name}' added to cart."

    @staticmethod
    def update_quantity(user, item_id: int, quantity: int) -> tuple[bool, str]:
        """Set an absolute quantity (0 removes the line)."""
        line = CartService.find_item(user, item_id)
        if line is None:
            return False, "Cart item not found."
        if quantity <= 0:
            return CartService.remove(user, item_id)

        food = line.food_item
        if food is None or not food.is_active or not food.is_available:
            db.session.delete(line)
            db.session.commit()
            return False, "That item is no longer available and was removed from your cart."

        quantity = clamp_qty(quantity, 1, MAX_QTY_PER_ITEM)
        if quantity > food.stock_quantity:
            return False, f"Only {food.stock_quantity} x '{food.name}' left in stock."

        line.quantity = quantity
        db.session.commit()
        return True, "Cart updated."

    @staticmethod
    def increment(user, item_id: int) -> tuple[bool, str]:
        line = CartService.find_item(user, item_id)
        if line is None:
            return False, "Cart item not found."
        return CartService.update_quantity(user, item_id, line.quantity + 1)

    @staticmethod
    def decrement(user, item_id: int) -> tuple[bool, str]:
        line = CartService.find_item(user, item_id)
        if line is None:
            return False, "Cart item not found."
        return CartService.update_quantity(user, item_id, line.quantity - 1)

    @staticmethod
    def remove(user, item_id: int) -> tuple[bool, str]:
        line = CartService.find_item(user, item_id)
        if line is None:
            return False, "Cart item not found."
        db.session.delete(line)
        db.session.commit()
        return True, "Item removed from cart."

    @staticmethod
    def clear(user) -> tuple[bool, str]:
        cart = Cart.query.filter_by(user_id=user.id).first()
        if cart is None:
            return True, "Cart is already empty."
        CartItem.query.filter_by(cart_id=cart.id).delete(synchronize_session=False)
        db.session.commit()
        return True, "Cart cleared."

    @staticmethod
    def clear_items(cart: Cart) -> None:
        """Remove all lines inside the caller's transaction (no commit)."""
        for line in list(cart.items):
            db.session.delete(line)

    # ------------------------------------------------------------------
    @staticmethod
    def validate(user) -> tuple[bool, str, list]:
        """Re-validate every line before checkout. Returns (ok, msg, lines)."""
        cart = Cart.query.filter_by(user_id=user.id).first()
        if cart is None or not cart.items:
            return False, "Your cart is empty.", []

        lines = []
        for line in cart.items:
            food = line.food_item
            if food is None or not food.is_active:
                return False, "An item in your cart is no longer on the menu.", []
            if not food.is_available or food.stock_quantity <= 0:
                return False, f"'{food.name}' is out of stock.", []
            if line.quantity > food.stock_quantity:
                return False, (
                    f"Only {food.stock_quantity} x '{food.name}' available "
                    f"(you have {line.quantity} in cart)."
                ), []
            if line.quantity > MAX_QTY_PER_ITEM:
                return False, f"Too many x '{food.name}' in cart (max {MAX_QTY_PER_ITEM}).", []
            lines.append((food, line.quantity))

        return True, "Cart is valid.", lines

    @staticmethod
    def subtotal(cart: Cart) -> float:
        return round(
            sum(float(i.food_item.price) * i.quantity for i in cart.items if i.food_item), 2
        )
