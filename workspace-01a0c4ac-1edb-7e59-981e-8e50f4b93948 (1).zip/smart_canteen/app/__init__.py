"""Smart Canteen - Flask application factory.

Three-tier architecture:
    Presentation : app/templates + app/static (HTML5 / CSS3 / JavaScript)
    Application  : app/routes + app/services + app/forms + app/utils
    Data         : app/models (SQLAlchemy ORM over SQLite)
"""
import os
from datetime import datetime

from flask import Flask, render_template, request
from flask_login import LoginManager, current_user
from flask_sqlalchemy import SQLAlchemy
from flask_wtf.csrf import CSRFProtect, CSRFError, generate_csrf
from werkzeug.middleware.proxy_fix import ProxyFix

db = SQLAlchemy()
login_manager = LoginManager()
csrf = CSRFProtect()


def create_app(config_object=None):
    """Build and configure the Flask application."""
    from config import get_config

    if config_object is None:
        config_object = get_config()

    app = Flask(__name__, instance_relative_config=True)
    app.config.from_object(config_object)
    app.wsgi_app = ProxyFix(app.wsgi_app, x_for=1, x_proto=1)  # pragma: no cover

    # ---- filesystem prerequisites -------------------------------------------
    os.makedirs(app.instance_path, exist_ok=True)
    os.makedirs(app.config["UPLOAD_FOLDER"], exist_ok=True)

    # ---- extensions ---------------------------------------------------------
    db.init_app(app)
    login_manager.init_app(app)
    csrf.init_app(app)
    login_manager.login_view = "auth.login"
    login_manager.login_message = "Please log in to continue."
    login_manager.login_message_category = "warning"

    @app.before_request
    def _resolve_login_per_request():
        """Resolve Flask-Login's user from THIS request's session.

        Flask-Login caches the user on `g`, which lives for the whole app
        context. In tests (and some embedded setups) multiple requests share
        one app context — clearing the cache first guarantees each request is
        authenticated from its own session cookie only.
        """
        from flask import g

        g.pop("_login_user", None)

    # Register models (also wires up the Flask-Login user loader).
    from app import models  # noqa: F401

    # ---- blueprints (application layer) -------------------------------------
    from app.routes.auth import bp as auth_bp
    from app.routes.main import bp as main_bp
    from app.routes.menu import bp as menu_bp
    from app.routes.cart import bp as cart_bp
    from app.routes.checkout import bp as checkout_bp
    from app.routes.orders import bp as orders_bp
    from app.routes.notifications import bp as notifications_bp
    from app.routes.admin import bp as admin_bp

    app.register_blueprint(auth_bp)
    app.register_blueprint(main_bp)
    app.register_blueprint(menu_bp)
    app.register_blueprint(cart_bp)
    app.register_blueprint(checkout_bp)
    app.register_blueprint(orders_bp)
    app.register_blueprint(notifications_bp)
    app.register_blueprint(admin_bp)

    # ---- error pages --------------------------------------------------------
    def _error_handler(error):
        code = getattr(error, "code", 500)
        if code not in (400, 401, 403, 404, 500):
            code = 500
        return render_template(f"errors/{code}.html", error=error), code

    for code in (400, 401, 403, 404, 500):
        app.errorhandler(code)(_error_handler)

    @app.errorhandler(CSRFError)
    def handle_csrf_error(e):  # pragma: no cover - exercised via UI
        return render_template("errors/400.html", error=e), 400

    # ---- template globals / filters -----------------------------------------
    from app.models.order import OrderStatus
    from app.models.notification import NotificationType
    from app.utils.helpers import money, time_ago, format_dt

    app.jinja_env.filters["money"] = money
    app.jinja_env.filters["timeago"] = time_ago
    app.jinja_env.filters["dt"] = format_dt
    # Also expose as Jinja globals so macros (imported without context) can use them
    app.jinja_env.globals["OrderStatus"] = OrderStatus
    app.jinja_env.globals["NotificationType"] = NotificationType

    @app.context_processor
    def inject_globals():
        """Values every template needs: cart badge, notifications, settings."""
        from app.services.settings_service import SettingsService

        cart_count = 0
        unread = 0
        if current_user.is_authenticated:
            from app.services.cart_service import CartService

            cart_count = CartService.item_count(current_user)
            unread = current_user.unread_notifications_count()

        return dict(
            cart_count=cart_count,
            unread_count=unread,
            app_settings=SettingsService.all(),
            OrderStatus=OrderStatus,
            NotificationType=NotificationType,
            csrf_token=generate_csrf,
            current_year=datetime.utcnow().year,
        )

    @app.after_request
    def set_security_headers(response):
        """Baseline security headers (XSS / clickjacking / sniffing protection)."""
        response.headers.setdefault("X-Content-Type-Options", "nosniff")
        response.headers.setdefault("X-Frame-Options", "SAMEORIGIN")
        response.headers.setdefault("Referrer-Policy", "strict-origin-when-cross-origin")
        response.headers.setdefault(
            "Content-Security-Policy",
            "default-src 'self'; img-src 'self' data:; style-src 'self' 'unsafe-inline'; "
            "script-src 'self' 'unsafe-inline'; font-src 'self' data:; connect-src 'self'",
        )
        return response

    # ---- database -----------------------------------------------------------
    with app.app_context():
        db.create_all()

    return app
