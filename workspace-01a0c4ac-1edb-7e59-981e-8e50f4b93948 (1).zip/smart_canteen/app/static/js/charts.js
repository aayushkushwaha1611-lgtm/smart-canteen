/* ============================================================
   Smart Canteen — charts.js
   Self-contained canvas chart library (no CDN dependency):
   SCCharts.bar(canvas, labels, values, opts)
   SCCharts.line(canvas, labels, values, opts)
   SCCharts.doughnut(canvas, labels, values, colors, opts)
   ============================================================ */
(function (global) {
  "use strict";

  const FONT = '600 11px "Segoe UI", system-ui, sans-serif';
  const PALETTE = ["#f97316", "#3b82f6", "#22c55e", "#8b5cf6", "#14b8a6", "#ef4444", "#f59e0b", "#0ea5e9"];

  function setup(canvas, height) {
    const dpr = global.devicePixelRatio || 1;
    const width = canvas.parentElement ? canvas.parentElement.clientWidth - 8 : 480;
    const h = height || canvas.height || 240;
    canvas.width = width * dpr;
    canvas.height = h * dpr;
    canvas.style.width = width + "px";
    canvas.style.height = h + "px";
    const ctx = canvas.getContext("2d");
    ctx.scale(dpr, dpr);
    ctx.font = FONT;
    return { ctx, width, height: h };
  }

  function maxOf(values) {
    return Math.max(1, ...values.map((v) => Number(v) || 0));
  }

  function fmt(value, opts) {
    const prefix = (opts && opts.prefix) || "";
    const v = Number(value) || 0;
    return prefix + (v >= 1000 ? (v / 1000).toFixed(1) + "k" : Math.round(v * 100) / 100);
  }

  function grid(ctx, width, height, pad, max, opts) {
    ctx.strokeStyle = "#e2e8f0";
    ctx.fillStyle = "#94a3b8";
    ctx.textAlign = "right";
    ctx.textBaseline = "middle";
    for (let i = 0; i <= 4; i++) {
      const y = pad.top + ((height - pad.top - pad.bottom) * i) / 4;
      ctx.beginPath();
      ctx.moveTo(pad.left, y);
      ctx.lineTo(width - pad.right, y);
      ctx.stroke();
      ctx.fillText(fmt((max * (4 - i)) / 4, opts), pad.left - 6, y);
    }
  }

  function legend(ctx, labels, colors, width, height) {
    let x = 8;
    const y = height - 6;
    ctx.textAlign = "left";
    ctx.textBaseline = "middle";
    labels.forEach((label, i) => {
      ctx.fillStyle = colors[i % colors.length];
      ctx.fillRect(x, y - 5, 10, 10);
      ctx.fillStyle = "#475569";
      ctx.fillText(String(label).slice(0, 14), x + 14, y);
      x += 28 + String(label).slice(0, 14).length * 6.4;
    });
  }

  function bar(canvas, labels, values, opts) {
    opts = opts || {};
    const { ctx, width, height } = setup(canvas, opts.height);
    const horizontal = !!opts.horizontal;
    const max = maxOf(values);
    const color = opts.color || PALETTE[0];

    if (horizontal) {
      const pad = { top: 6, right: 44, bottom: 22, left: 110 };
      const rowH = (height - pad.top - pad.bottom) / Math.max(1, values.length);
      values.forEach((v, i) => {
        const y = pad.top + i * rowH + rowH * 0.15;
        const barW = ((width - pad.left - pad.right) * (Number(v) || 0)) / max;
        ctx.fillStyle = "#475569";
        ctx.textAlign = "right";
        ctx.textBaseline = "middle";
        ctx.fillText(labels[i], pad.left - 8, y + rowH * 0.35);
        ctx.fillStyle = color;
        roundRect(ctx, pad.left, y, Math.max(barW, 2), rowH * 0.7, 4);
        ctx.fill();
        ctx.textAlign = "left";
        ctx.fillStyle = "#0f172a";
        ctx.fillText(fmt(v, opts), pad.left + barW + 6, y + rowH * 0.35);
      });
      return;
    }

    const pad = { top: 12, right: 8, bottom: 30, left: 38 };
    grid(ctx, width, height, pad, max, opts);
    const step = (width - pad.left - pad.right) / Math.max(1, values.length);
    const barW = Math.min(step * 0.55, 42);
    values.forEach((v, i) => {
      const x = pad.left + i * step + (step - barW) / 2;
      const barH = ((height - pad.top - pad.bottom) * (Number(v) || 0)) / max;
      const y = height - pad.bottom - barH;
      const grad = ctx.createLinearGradient(0, y, 0, height - pad.bottom);
      grad.addColorStop(0, color);
      grad.addColorStop(1, color + "aa");
      ctx.fillStyle = grad;
      roundRect(ctx, x, y, barW, Math.max(barH, 2), 5);
      ctx.fill();
      ctx.fillStyle = "#475569";
      ctx.textAlign = "center";
      ctx.textBaseline = "top";
      ctx.fillText(String(labels[i]).slice(0, 8), x + barW / 2, height - pad.bottom + 6);
      if (Number(v) > 0) {
        ctx.fillStyle = "#0f172a";
        ctx.textBaseline = "bottom";
        ctx.fillText(fmt(v, opts), x + barW / 2, y - 2);
      }
    });
  }

  function line(canvas, labels, values, opts) {
    opts = opts || {};
    const { ctx, width, height } = setup(canvas, opts.height);
    const max = maxOf(values);
    const color = opts.color || PALETTE[1];
    const pad = { top: 14, right: 12, bottom: 28, left: 42 };
    grid(ctx, width, height, pad, max, opts);

    const stepX = (width - pad.left - pad.right) / Math.max(1, values.length - 1 || 1);
    const points = values.map((v, i) => ({
      x: pad.left + (values.length === 1 ? (width - pad.left - pad.right) / 2 : i * stepX),
      y: height - pad.bottom - ((height - pad.top - pad.bottom) * (Number(v) || 0)) / max,
    }));

    if (opts.fill !== false && points.length) {
      ctx.beginPath();
      ctx.moveTo(points[0].x, height - pad.bottom);
      points.forEach((p) => ctx.lineTo(p.x, p.y));
      ctx.lineTo(points[points.length - 1].x, height - pad.bottom);
      ctx.closePath();
      const grad = ctx.createLinearGradient(0, pad.top, 0, height - pad.bottom);
      grad.addColorStop(0, color + "40");
      grad.addColorStop(1, color + "05");
      ctx.fillStyle = grad;
      ctx.fill();
    }

    ctx.beginPath();
    ctx.strokeStyle = color;
    ctx.lineWidth = 2.5;
    ctx.lineJoin = "round";
    points.forEach((p, i) => (i ? ctx.lineTo(p.x, p.y) : ctx.moveTo(p.x, p.y)));
    ctx.stroke();

    points.forEach((p, i) => {
      ctx.beginPath();
      ctx.fillStyle = "#fff";
      ctx.strokeStyle = color;
      ctx.lineWidth = 2;
      ctx.arc(p.x, p.y, 3.5, 0, Math.PI * 2);
      ctx.fill();
      ctx.stroke();
      if (Number(values[i]) > 0) {
        ctx.fillStyle = "#0f172a";
        ctx.textAlign = "center";
        ctx.textBaseline = "bottom";
        ctx.fillText(fmt(values[i], opts), p.x, p.y - 6);
      }
    });

    ctx.fillStyle = "#475569";
    ctx.textAlign = "center";
    ctx.textBaseline = "top";
    const every = Math.ceil(labels.length / 8);
    labels.forEach((label, i) => {
      if (i % every === 0 || i === labels.length - 1) {
        ctx.fillText(String(label).slice(0, 8), points[i].x, height - pad.bottom + 6);
      }
    });
  }

  function doughnut(canvas, labels, values, colors, opts) {
    opts = opts || {};
    colors = colors && colors.length ? colors : PALETTE;
    const { ctx, width, height } = setup(canvas, opts.height);
    const total = values.reduce((s, v) => s + (Number(v) || 0), 0);
    const cx = width / 2;
    const cy = (height - 34) / 2;
    const R = Math.min(cx, cy) - 8;
    const r = R * 0.62;

    if (total <= 0) {
      ctx.fillStyle = "#94a3b8";
      ctx.textAlign = "center";
      ctx.fillText("No data yet", cx, cy);
      return;
    }

    let angle = -Math.PI / 2;
    values.forEach((v, i) => {
      const slice = (Number(v) / total) * Math.PI * 2;
      ctx.beginPath();
      ctx.fillStyle = colors[i % colors.length];
      ctx.arc(cx, cy, R, angle, angle + slice);
      ctx.arc(cx, cy, r, angle + slice, angle, true);
      ctx.closePath();
      ctx.fill();
      angle += slice;
    });

    ctx.fillStyle = "#0f172a";
    ctx.textAlign = "center";
    ctx.textBaseline = "middle";
    ctx.font = '800 16px "Segoe UI", system-ui, sans-serif';
    ctx.fillText(fmt(total, opts), cx, cy - 8);
    ctx.font = FONT;
    ctx.fillStyle = "#94a3b8";
    ctx.fillText("total", cx, cy + 10);

    legend(ctx, labels, colors, width, height);
  }

  function roundRect(ctx, x, y, w, h, radius) {
    radius = Math.min(radius, w / 2, h / 2);
    ctx.beginPath();
    ctx.moveTo(x + radius, y);
    ctx.arcTo(x + w, y, x + w, y + h, radius);
    ctx.arcTo(x + w, y + h, x, y + h, 0);
    ctx.arcTo(x, y + h, x, y, 0);
    ctx.arcTo(x, y, x + w, y, radius);
    ctx.closePath();
  }

  global.SCCharts = { bar, line, doughnut };
})(window);
