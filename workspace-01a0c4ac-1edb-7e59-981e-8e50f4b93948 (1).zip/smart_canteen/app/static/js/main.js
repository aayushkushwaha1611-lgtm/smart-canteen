/* ============================================================
   Smart Canteen — main.js (presentation layer behaviour)
   Toasts, modals, confirm dialogs, AJAX cart, notification poll,
   responsive navigation. All writes send the CSRF token.
   ============================================================ */
(function () {
  "use strict";

  const CSRF = document.querySelector('meta[name="csrf-token"]')?.content || "";
  const toastStack = document.getElementById("toast-stack");

  /* ---------------- Toasts ---------------- */
  function toast(message, type) {
    if (!toastStack) return;
    const el = document.createElement("div");
    el.className = "toast toast--" + (type || "info");
    el.textContent = message;
    toastStack.appendChild(el);
    setTimeout(() => {
      el.classList.add("is-leaving");
      setTimeout(() => el.remove(), 350);
    }, 3800);
  }
  window.SCUI = { toast };

  // Lift server flash messages into toasts
  try {
    const flashEl = document.getElementById("flash-data");
    const flashes = JSON.parse(flashEl?.dataset.flash || "[]");
    flashes.forEach(([category, message]) => toast(message, category));
  } catch (e) { /* no flash */ }

  /* ---------------- Fetch helper (CSRF-aware) ---------------- */
  async function api(url, data) {
    const body = new FormData();
    Object.entries(data || {}).forEach(([k, v]) => body.append(k, v));
    body.append("csrf_token", CSRF);
    const res = await fetch(url, {
      method: "POST",
      body,
      headers: { "X-Requested-With": "fetch" },
    });
    let json = {};
    try { json = await res.json(); } catch (e) { /* empty */ }
    return { ok: res.ok && json.ok !== false, status: res.status, data: json };
  }

  /* ---------------- Modal + confirm dialogs ---------------- */
  const overlay = document.getElementById("modal-overlay");
  const modalContent = document.getElementById("modal-content");

  function openModal(html) {
    if (!overlay || !modalContent) return;
    modalContent.innerHTML = html;
    overlay.hidden = false;
  }
  function closeModal() {
    if (overlay) overlay.hidden = true;
    if (modalContent) modalContent.innerHTML = "";
  }
  document.getElementById("modal-close")?.addEventListener("click", closeModal);
  overlay?.addEventListener("click", (e) => { if (e.target === overlay) closeModal(); });
  document.addEventListener("keydown", (e) => { if (e.key === "Escape") closeModal(); });

  function confirmDialog(message) {
    return new Promise((resolve) => {
      openModal(
        '<h3>Are you sure?</h3><p>' + message.replace(/</g, "&lt;") + "</p>" +
        '<div class="modal__actions">' +
        '<button class="btn btn--ghost" id="m-no">No, keep it</button>' +
        '<button class="btn btn--danger" id="m-yes">Yes, continue</button></div>'
      );
      document.getElementById("m-no").onclick = () => { closeModal(); resolve(false); };
      document.getElementById("m-yes").onclick = () => { closeModal(); resolve(true); };
    });
  }

  // Intercept any form marked [data-confirm] (deletes, cancels, clears…)
  document.addEventListener("submit", async (e) => {
    const form = e.target;
    if (!(form instanceof HTMLFormElement) || !form.dataset.confirm) return;
    e.preventDefault();
    if (await confirmDialog(form.dataset.confirm)) form.submit();
  }, true);

  /* ---------------- AJAX cart forms (progressive enhancement) ---------------- */
  function updateCartUI(data) {
    document.querySelectorAll(".js-cart-count").forEach((el) => {
      el.textContent = data.cart_count ?? 0;
    });
    document.querySelectorAll("[data-cart-subtotal]").forEach((el) => {
      if (data.subtotal != null) el.textContent = fmtMoney(data.subtotal);
    });
    document.querySelectorAll("[data-cart-total]").forEach((el) => {
      if (data.subtotal != null) el.textContent = fmtMoney(data.subtotal);
    });
  }

  function fmtMoney(value) {
    // Matches the server |money filter closely (₹ with Indian grouping).
    let [whole, frac] = Number(value).toFixed(2).split(".");
    let sign = whole.startsWith("-") ? "-" : "";
    let digits = whole.replace("-", "");
    if (digits.length > 3) {
      const head = digits.slice(0, -3).replace(/\B(?=(\d{2})+(?!\d))/g, ",");
      digits = head + "," + digits.slice(-3);
    }
    return sign + "\u20B9" + digits + "." + frac;
  }

  document.addEventListener("submit", async (e) => {
    const form = e.target;
    if (!(form instanceof HTMLFormElement)) return;
    if (!form.classList.contains("js-cart-form") && !form.classList.contains("js-ajax-form")) return;
    e.preventDefault();
    const btn = form.querySelector('button[type="submit"], button:not([type])');
    if (btn) btn.classList.add("loading-btn");

    const payload = {};
    new FormData(form).forEach((v, k) => { if (k !== "csrf_token") payload[k] = v; });

    try {
      const result = await api(form.action, payload);
      toast(result.data.message || (result.ok ? "Done." : "Something went wrong."),
            result.data.ok ? "success" : (result.data.message ? "warning" : "danger"));
      updateCartUI(result.data);
      if (form.classList.contains("js-cart-form") && form.closest("#cart-lines") && result.data.lines) {
        refreshCartLines(result.data);
      }
      if (form.classList.contains("js-ajax-form")) {
        const row = form.closest(".notif");
        if (row) { row.classList.remove("is-unread"); form.remove(); }
        const badge = document.querySelector(".js-unread-count");
        if (badge && result.data.unread != null) badge.textContent = result.data.unread;
      }
      // Stock may have changed (e.g. last item) — reload cart page if empty.
      if (result.data.lines && result.data.lines.length === 0 &&
          window.location.pathname === "/cart") {
        window.location.reload();
      }
    } catch (err) {
      toast("Network error — please try again.", "danger");
    } finally {
      if (btn) btn.classList.remove("loading-btn");
    }
  });

  function refreshCartLines(data) {
    data.lines.forEach((line) => {
      const row = document.querySelector('[data-line-id="' + line.id + '"]');
      if (!row) return;
      const total = row.querySelector("[data-line-total]");
      if (total) total.textContent = fmtMoney(line.line_total);
      const qty = row.querySelector(".qty-value");
      if (qty) qty.textContent = line.quantity;
      // keep hidden quantity fields in sync for +/- forms
      const forms = row.querySelectorAll(".qty-form");
      if (forms[0]) forms[0].querySelector('input[name="quantity"]').value = line.quantity - 1;
      if (forms[1]) forms[1].querySelector('input[name="quantity"]').value = line.quantity + 1;
    });
  }

  /* ---------------- Navbar / sidebar toggles ---------------- */
  const navToggle = document.getElementById("nav-toggle");
  const primaryNav = document.getElementById("primary-nav");
  navToggle?.addEventListener("click", () => {
    const open = primaryNav.classList.toggle("is-open");
    navToggle.setAttribute("aria-expanded", String(open));
  });

  const sidebarToggle = document.getElementById("sidebar-toggle");
  const sidebar = document.getElementById("sidebar");
  sidebarToggle?.addEventListener("click", () => sidebar?.classList.toggle("is-open"));

  const dropdown = document.getElementById("account-dropdown");
  dropdown?.querySelector(".nav__account")?.addEventListener("click", () => {
    dropdown.classList.toggle("is-open");
  });
  document.addEventListener("click", (e) => {
    if (dropdown && !dropdown.contains(e.target)) dropdown.classList.remove("is-open");
  });

  /* ---------------- Qty picker (food detail) ---------------- */
  document.querySelectorAll(".qty-picker").forEach((picker) => {
    const input = picker.querySelector(".qty-input");
    picker.querySelectorAll(".qty-btn").forEach((btn) => {
      btn.addEventListener("click", () => {
        const step = Number(btn.dataset.qty || 0);
        const min = Number(input.min || 1);
        const max = Number(input.max || 99);
        input.value = Math.max(min, Math.min(max, Number(input.value || 1) + step));
      });
    });
  });

  /* ---------------- Notification unread poll ---------------- */
  const badge = document.querySelector(".js-unread-count");
  if (badge) {
    setInterval(async () => {
      try {
        const res = await fetch("/api/notifications/unread-count");
        if (res.ok) {
          const data = await res.json();
          badge.textContent = data.count;
        }
      } catch (e) { /* offline — ignore */ }
    }, 45000);
  }
})();
