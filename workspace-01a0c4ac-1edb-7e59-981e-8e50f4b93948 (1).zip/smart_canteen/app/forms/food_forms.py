"""Food / category / inventory management forms (admin)."""
from flask_wtf import FlaskForm
from flask_wtf.file import FileAllowed, FileField
from wtforms import (
    BooleanField,
    DecimalField,
    IntegerField,
    SelectField,
    StringField,
    SubmitField,
    TextAreaField,
)
from wtforms.validators import (
    DataRequired,
    Length,
    NumberRange,
    Optional,
    ValidationError,
)

from app.models import Category, FoodItem
from app.utils.helpers import slugify


class CategoryForm(FlaskForm):
    name = StringField(
        "Category Name", validators=[DataRequired(), Length(min=2, max=60)]
    )
    description = StringField("Description", validators=[Optional(), Length(max=255)])
    sort_order = IntegerField(
        "Sort Order", default=0, validators=[NumberRange(min=0, max=999)]
    )
    is_active = BooleanField("Active", default=True)
    submit = SubmitField("Save Category")

    def __init__(self, original=None, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.original = original

    def validate_name(self, field):
        name = field.data.strip()
        base = slugify(name)
        clash = Category.query.filter(
            (Category.name == name) | (Category.slug == base)
        ).first()
        if clash and (self.original is None or clash.id != self.original.id):
            raise ValidationError("A category with this name already exists.")


class FoodForm(FlaskForm):
    name = StringField("Food Name", validators=[DataRequired(), Length(min=2, max=120)])
    category_id = SelectField("Category", coerce=int, validators=[DataRequired()])
    price = DecimalField(
        "Price (₹)",
        places=2,
        validators=[DataRequired(), NumberRange(min=1, max=5000, message="Price must be between ₹1 and ₹5000.")],
    )
    description = TextAreaField("Description", validators=[Optional(), Length(max=2000)])
    prep_time_minutes = IntegerField(
        "Preparation Time (minutes)",
        default=10,
        validators=[DataRequired(), NumberRange(min=1, max=180)],
    )
    stock_quantity = IntegerField(
        "Stock Quantity", default=0, validators=[DataRequired(), NumberRange(min=0, max=9999)]
    )
    low_stock_threshold = IntegerField(
        "Low-Stock Threshold", default=5, validators=[DataRequired(), NumberRange(min=0, max=999)]
    )
    is_available = BooleanField("Available for ordering", default=True)
    is_active = BooleanField("Active (visible on menu)", default=True)
    is_special = BooleanField("Mark as Today's Special", default=False)
    image = FileField(
        "Food Photo",
        validators=[Optional(), FileAllowed(["jpg", "jpeg", "png", "gif", "webp"], "Images only!")],
    )
    submit = SubmitField("Save Food Item")

    def __init__(self, original=None, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.original = original
        self.category_id.choices = [
            (c.id, c.name) for c in Category.query.filter_by(is_active=True).order_by(Category.sort_order).all()
        ] or [(0, "— create a category first —")]

    def validate_name(self, field):
        name = field.data.strip()
        clash = FoodItem.query.filter_by(name=name).first()
        if clash and (self.original is None or clash.id != self.original.id):
            raise ValidationError("A food item with this name already exists.")

    def validate_category_id(self, field):
        if not Category.query.get(field.data):
            raise ValidationError("Please choose a valid category.")


class StockUpdateForm(FlaskForm):
    """Quick inventory restock / adjust form."""

    stock_quantity = IntegerField(
        "New Stock Quantity", validators=[DataRequired(), NumberRange(min=0, max=9999)]
    )
    low_stock_threshold = IntegerField(
        "Low-Stock Threshold", default=5, validators=[DataRequired(), NumberRange(min=0, max=999)]
    )
    is_available = BooleanField("Available for ordering", default=True)
    submit = SubmitField("Update Stock")
