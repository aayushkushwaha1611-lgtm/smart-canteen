"""Authentication and profile forms."""
from flask_wtf import FlaskForm
from wtforms import (
    BooleanField,
    EmailField,
    PasswordField,
    StringField,
    SubmitField,
    TelField,
)
from wtforms.validators import (
    DataRequired,
    Email,
    EqualTo,
    Length,
    Optional,
    Regexp,
    ValidationError,
)

from app.models import User
from app.utils.validators import is_phone, is_roll_number


class RegisterForm(FlaskForm):
    full_name = StringField(
        "Full Name",
        validators=[DataRequired("Please enter your name."), Length(min=2, max=120)],
    )
    email = EmailField(
        "Email",
        validators=[DataRequired(), Email("Enter a valid email."), Length(max=120)],
    )
    roll_number = StringField(
        "Roll Number",
        validators=[
            DataRequired(),
            Regexp(r"^[A-Za-z0-9/\-]{3,30}$", message="3-30 letters, digits, / or - only."),
        ],
    )
    phone = TelField("Phone (optional)", validators=[Optional(), Length(max=15)])
    password = PasswordField(
        "Password",
        validators=[
            DataRequired(),
            Length(min=8, max=128, message="Password must be at least 8 characters."),
        ],
    )
    confirm_password = PasswordField(
        "Confirm Password",
        validators=[DataRequired(), EqualTo("password", message="Passwords must match.")],
    )
    accept_terms = BooleanField(
        "I agree to the canteen terms", validators=[DataRequired("You must accept the terms.")]
    )
    submit = SubmitField("Create Account")

    def validate_email(self, field):
        if User.query.filter_by(email=field.data.lower().strip()).first():
            raise ValidationError("An account with this email already exists.")

    def validate_roll_number(self, field):
        value = field.data.strip().upper()
        if not is_roll_number(value):
            raise ValidationError("Invalid roll number format.")
        if User.query.filter_by(roll_number=value).first():
            raise ValidationError("This roll number is already registered.")

    def validate_phone(self, field):
        if not is_phone(field.data):
            raise ValidationError("Enter a valid 10-digit Indian mobile number.")


class LoginForm(FlaskForm):
    email = EmailField("Email", validators=[DataRequired(), Email(), Length(max=120)])
    password = PasswordField("Password", validators=[DataRequired()])
    remember = BooleanField("Remember me")
    submit = SubmitField("Sign In")


class ProfileForm(FlaskForm):
    full_name = StringField(
        "Full Name", validators=[DataRequired(), Length(min=2, max=120)]
    )
    email = EmailField(
        "Email", validators=[DataRequired(), Email(), Length(max=120)]
    )
    roll_number = StringField(
        "Roll Number",
        validators=[DataRequired(), Regexp(r"^[A-Za-z0-9/\-]{3,30}$")],
    )
    phone = TelField("Phone", validators=[Optional(), Length(max=15)])
    submit = SubmitField("Save Changes")

    def __init__(self, original_user=None, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.original_user = original_user

    def validate_email(self, field):
        email = field.data.lower().strip()
        user = User.query.filter_by(email=email).first()
        if user and (self.original_user is None or user.id != self.original_user.id):
            raise ValidationError("This email is already in use.")

    def validate_roll_number(self, field):
        value = field.data.strip().upper()
        user = User.query.filter_by(roll_number=value).first()
        if user and (self.original_user is None or user.id != self.original_user.id):
            raise ValidationError("This roll number is already in use.")

    def validate_phone(self, field):
        if not is_phone(field.data):
            raise ValidationError("Enter a valid 10-digit Indian mobile number.")


class ChangePasswordForm(FlaskForm):
    current_password = PasswordField("Current Password", validators=[DataRequired()])
    new_password = PasswordField(
        "New Password",
        validators=[
            DataRequired(),
            Length(min=8, max=128, message="Password must be at least 8 characters."),
        ],
    )
    confirm_password = PasswordField(
        "Confirm New Password",
        validators=[DataRequired(), EqualTo("new_password", message="Passwords must match.")],
    )
    submit = SubmitField("Change Password")
