"""Checkout and application-settings forms."""
from flask_wtf import FlaskForm
from wtforms import BooleanField, IntegerField, StringField, SubmitField, TextAreaField
from wtforms.validators import DataRequired, Length, NumberRange, Optional


class CheckoutForm(FlaskForm):
    notes = TextAreaField(
        "Order Notes",
        validators=[Optional(), Length(max=500)],
        description="e.g. less spicy, no onion, extra chutney",
    )
    confirm = BooleanField(
        "I confirm this order and will collect it at the canteen counter",
        validators=[DataRequired("Please confirm the order.")],
    )
    submit = SubmitField("Place Order & Get Token")


class SettingsForm(FlaskForm):
    """Admin settings: pickup instructions and low-stock defaults."""

    canteen_name = StringField("Canteen Name", validators=[DataRequired(), Length(max=80)])
    pickup_location = StringField(
        "Pickup Location", validators=[DataRequired(), Length(max=120)]
    )
    pickup_message = TextAreaField(
        "Pickup Message (shown at checkout)",
        validators=[Optional(), Length(max=300)],
    )
    cancel_window_minutes = IntegerField(
        "Student cancellation window (minutes)",
        validators=[DataRequired(), NumberRange(min=1, max=120)],
    )
    low_stock_default = IntegerField(
        "Default low-stock threshold",
        validators=[DataRequired(), NumberRange(min=1, max=100)],
    )
    submit = SubmitField("Save Settings")
