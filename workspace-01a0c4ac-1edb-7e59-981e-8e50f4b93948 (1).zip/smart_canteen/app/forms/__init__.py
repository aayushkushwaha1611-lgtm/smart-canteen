"""WTForms: form definitions + validation (CSRF handled automatically)."""
from app.forms.auth_forms import RegisterForm, LoginForm, ProfileForm, ChangePasswordForm
from app.forms.food_forms import FoodForm, CategoryForm, StockUpdateForm
from app.forms.order_forms import CheckoutForm, SettingsForm

__all__ = [
    "RegisterForm",
    "LoginForm",
    "ProfileForm",
    "ChangePasswordForm",
    "FoodForm",
    "CategoryForm",
    "StockUpdateForm",
    "CheckoutForm",
    "SettingsForm",
]
