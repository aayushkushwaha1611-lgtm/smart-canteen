"""Cross-cutting helper functions: formatting, slugs, uploads, logging."""
import os
import re
import unicodedata
import uuid
from datetime import datetime
from zoneinfo import ZoneInfo

from flask import current_app, request
from flask_login import current_user
from werkzeug.utils import secure_filename

IST = ZoneInfo("Asia/Kolkata")

_MONEY_CHARS = re.compile(r"[^a-z0-9]+")


# --------------------------------------------------------------------------
# Time helpers (business day is the IST calendar day)
# --------------------------------------------------------------------------
def ist_now() -> datetime:
    return datetime.now(IST)


def to_ist(dt: datetime | None) -> datetime | None:
    """Naive UTC datetimes from the DB are interpreted as UTC and shown in IST."""
    if dt is None:
        return None
    if dt.tzinfo is None:
        return dt.replace(tzinfo=ZoneInfo("UTC")).astimezone(IST)
    return dt.astimezone(IST)


def today_ist_date():
    return ist_now().date()


def format_dt(dt: datetime | None, fmt: str = "%d %b %Y, %I:%M %p") -> str:
    if dt is None:
        return "-"
    return to_ist(dt).strftime(fmt)


def time_ago(dt: datetime | None) -> str:
    if dt is None:
        return "-"
    diff = datetime.now(ZoneInfo("UTC")) - dt.replace(tzinfo=ZoneInfo("UTC")) if dt.tzinfo is None else datetime.now(IST) - dt
    seconds = int(diff.total_seconds())
    if seconds < 60:
        return "just now"
    if seconds < 3600:
        m = seconds // 60
        return f"{m} min ago"
    if seconds < 86400:
        h = seconds // 3600
        return f"{h} hr ago"
    d = seconds // 86400
    if d < 30:
        return f"{d} day{'s' if d > 1 else ''} ago"
    return format_dt(dt, "%d %b %Y")


# --------------------------------------------------------------------------
# Formatting
# --------------------------------------------------------------------------
def money(value) -> str:
    """Format a number as Indian Rupees with Indian digit grouping."""
    try:
        value = float(value)
    except (TypeError, ValueError):
        value = 0.0
    whole, _, frac = f"{value:.2f}".partition(".")
    sign = "-" if whole.startswith("-") else ""
    digits = whole.lstrip("-")
    if len(digits) > 3:
        head, tail = digits[:-3], digits[-3:]
        head = ",".join([head[max(0, i - 2) : i] for i in range(len(head), 0, -2)][::-1])
        digits = f"{head},{tail}"
    return f"{sign}₹{digits}.{frac}"


def slugify(text: str, fallback: str = "item") -> str:
    text = unicodedata.normalize("NFKD", str(text)).encode("ascii", "ignore").decode("ascii")
    slug = _MONEY_CHARS.sub("-", text.lower()).strip("-")
    return slug or fallback


def unique_slug(model, base: str) -> str:
    slug = slugify(base)
    candidate, n = slug, 1
    while model.query.filter_by(slug=candidate).first() is not None:
        n += 1
        candidate = f"{slug}-{n}"
    return candidate


# --------------------------------------------------------------------------
# File uploads (food images)
# --------------------------------------------------------------------------
def allowed_image(filename: str) -> bool:
    return (
        "." in filename
        and filename.rsplit(".", 1)[1].lower() in current_app.config["ALLOWED_IMAGE_EXTENSIONS"]
    )


def save_food_image(file_storage) -> str | None:
    """Validate and persist an uploaded image; returns the static-relative path."""
    if not file_storage or not file_storage.filename:
        return None
    if not allowed_image(file_storage.filename):
        raise ValueError("Unsupported image format. Use PNG, JPG, JPEG, GIF or WEBP.")
    ext = secure_filename(file_storage.filename).rsplit(".", 1)[1].lower()
    name = f"{uuid.uuid4().hex}.{ext}"
    path = os.path.join(current_app.config["UPLOAD_FOLDER"], name)
    file_storage.save(path)
    return f"uploads/foods/{name}"


def delete_food_image(static_path: str | None) -> None:
    """Remove a previously uploaded food image from disk."""
    if not static_path or not static_path.startswith("uploads/"):
        return
    full = os.path.join(current_app.root_path, "static", static_path)
    try:
        if os.path.isfile(full):
            os.remove(full)
    except OSError:  # pragma: no cover - best-effort cleanup
        pass


# --------------------------------------------------------------------------
# Activity logging
# --------------------------------------------------------------------------
def log_activity(action: str, entity_type: str | None = None, entity_id: int | None = None,
                 detail: str | None = None) -> None:
    """Persist an audit entry for an important action."""
    from app import db
    from app.models.activity import ActivityLog

    entry = ActivityLog(
        user_id=current_user.id if current_user.is_authenticated else None,
        action=action,
        entity_type=entity_type,
        entity_id=entity_id,
        detail=(detail[:490] if detail else None),
        ip_address=request.remote_addr if request else None,
    )
    db.session.add(entry)
