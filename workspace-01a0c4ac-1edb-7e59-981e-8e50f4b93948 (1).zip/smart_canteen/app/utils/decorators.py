"""Route protection: role-based authorization decorators."""
from functools import wraps

from flask import abort, redirect, request, url_for
from flask_login import current_user


def role_required(*roles):
    """Allow only authenticated, active users whose role is in *roles*.

    * Anonymous visitors are redirected to the login page (with ?next=).
    * Logged-in users with the wrong role (or a deactivated account) get a 403.
    * Calling with no roles allows any authenticated, active user.
    """

    def decorator(view):
        @wraps(view)
        def wrapped(*args, **kwargs):
            if not current_user.is_authenticated:
                return redirect(url_for("auth.login", next=request.path))
            if not current_user.is_active:
                abort(403, description="This account has been deactivated. Contact the canteen administrator.")
            if roles and current_user.role not in roles:
                abort(403, description="You do not have permission to access this page.")
            return view(*args, **kwargs)

        return wrapped

    return decorator


admin_required = role_required("admin")
student_required = role_required("student")
authenticated_required = role_required()
