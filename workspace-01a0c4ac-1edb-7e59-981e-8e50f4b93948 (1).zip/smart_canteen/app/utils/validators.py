"""Shared input validation helpers (server-side, always authoritative)."""
import re

EMAIL_RE = re.compile(r"^[A-Za-z0-9._%+\-]+@[A-Za-z0-9.\-]+\.[A-Za-z]{2,}$")
ROLL_RE = re.compile(r"^[A-Za-z0-9/\-]{3,30}$")
PHONE_RE = re.compile(r"^[6-9]\d{9}$")


def is_email(value: str) -> bool:
    return bool(value) and len(value) <= 120 and bool(EMAIL_RE.match(value))


def is_roll_number(value: str) -> bool:
    return bool(value) and bool(ROLL_RE.match(value.strip()))


def is_phone(value: str | None) -> bool:
    if value in (None, ""):
        return True
    return bool(PHONE_RE.match(str(value).strip()))


def is_positive_number(value) -> bool:
    try:
        return float(value) > 0
    except (TypeError, ValueError):
        return False


def is_non_negative_int(value) -> bool:
    try:
        return int(value) >= 0 and float(value) == int(value)
    except (TypeError, ValueError):
        return False


def clamp_qty(value, minimum: int = 1, maximum: int = 50) -> int:
    """Force a quantity into the allowed range (used by cart APIs)."""
    try:
        value = int(value)
    except (TypeError, ValueError):
        value = minimum
    return max(minimum, min(maximum, value))
